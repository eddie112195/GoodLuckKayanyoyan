
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Galvez Dental Clinic</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/animate.css">

    <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../assets/css/magnific-popup.css">

    <link rel="stylesheet" href="../assets/css/aos.css">
<link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/ionicons.min.css">

    <link rel="stylesheet" href="../assets/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../assets/css/jquery.timepicker.css">


    <link rel="stylesheet" href="../assets/css/flaticon.css">
    <link rel="stylesheet" href="../assets/css/icomoon.css">
    <link rel="stylesheet" href="../assets/css/style.css">
  </head>
  <body>

	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="patient.php">Galvez <span>Dental Clinic</span></a>
          <a href="patientapplist.php" class="navbar-brand">Appointment List</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
	          <li class="nav-item"><a href="doctors.php" class="nav-link">Doctors</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
            <li class="dropdown">

              <?php
              $queryy = mysqli_query($con,"SELECT a.*, b.*
                                      FROM patient a
                                      JOIN message b
                                      On b.PatientIc = a.icPatient WHERE b.status = 'unread'");

                  $arrayy = mysqli_fetch_all($queryy);
                if (count($arrayy) > 0) {
                ?>
                   <a class="nav-link" id="dropdown01" data-toggle= "dropdown" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i class="fa fa-bell"></i> Notification</i>
                     <span class="badge badge-light" style="background-color: red; font-size: 12px; color: white; border-radius: 50%!important"><?php echo count($arrayy); ?></span>
                   <?php
                 }
                  ?>
                     </a>
                   <ul class="dropdown-menu" style="margin-right: 40px">
                       <?php
                           if (count($arrayy) > 0) {
                             foreach ($queryy as $qww) {
                           ?>
                                <li>
                               <a style="
                                      <?php if($qww['status'] =='unread'){
                               echo "font-weight: bold; width: 200px";
                             }
                               ?>"
                                class="dropdown-item" href="view.php?patientId=<?php echo $qww['messageId']; ?>"><br/>
                                <i class="fa fa-fw fa-user"></i>
                                 <?php echo $qww['timeDate']; ?> <br><?php echo $qww['staff']; ?> of clinic.
                            <br>
                               <?php echo $qww['message']; ?>
                               <h6>Message</h6>
                               </a>
                             </li>

                           <?php
                           }
                         }


                        ?>
                   </ul>
                   </li>
              <i class="nav-link">Hi </i>
              <li class="dropdown nav-item cta">
									<a href="#" class="nav-link" data-toggle="dropdown"><i class="fa fa-user"></i>   <?php echo $userRow['patientFirstName']; ?><b class="caret"></b></a>
									<ul class="dropdown-menu" style="border-radius: 30px; width: 230px; background-color: gray">
										<li>
											<a href="profile.php?patientId=<?php echo $userRow['icPatient']; ?>" style="margin-left: 85px" class="nav-link"> Profile</a>

										</li>

										<li>
											<a href="patientapplist.php?patientId=<?php echo $userRow['icPatient']; ?>"style="margin-left: 55px" class="nav-link"><i class="glyphicon glyphicon-file"></i> Appointment list</a>
                    </li>
										<li class="divider"></li>
										<li>
											<a href="patientlogout.php?logout" style="margin-left: 80px" class="nav-link"> Log Out</a>
										</li>
									</ul>
								</li>

	        </ul>
	      </div>
	    </div>
	  </nav>
