<?php
session_start();
include_once '../assets/conn/dbconnect.php';
if(!isset($_SESSION['patientSession']))
{
header("Location: ../index.php");
}

$usersession = $_SESSION['patientSession'];


$res=mysqli_query($con,"SELECT * FROM patient WHERE icPatient='$usersession'");

if ($res===false) {
	echo mysql_error();
}

$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);
?>
<?php
$update12 = false;
if (isset($_GET['edit'])) {
  $update12 = true;

}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Galvez Dental Clinic</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/animate.css">

    <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../assets/css/magnific-popup.css">

    <link rel="stylesheet" href="../assets/css/aos.css">

    <link rel="stylesheet" href="../assets/css/ionicons.min.css">

    <link rel="stylesheet" href="../assets/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../assets/css/jquery.timepicker.css">


    <link rel="stylesheet" href="../assets/css/flaticon.css">
    <link rel="stylesheet" href="../assets/css/icomoon.css">
    <link rel="stylesheet" href="../assets/css/style.css">
  </head>
  <body>

	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="patient.php">Galvez <span>Dental Clinic</span></a>
          <a href="patientapplist.php" class="navbar-brand">Appointment List</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="patient.php" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
	          <li class="nav-item active"><a href="doctors.php" class="nav-link">Doctors</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
              <i class="nav-link">Hi </i>
              <li class="dropdown nav-item cta">
									<a href="#" class="nav-link" data-toggle="dropdown"><i class="fa fa-user"></i>   <?php echo $userRow['patientFirstName']; ?><b class="caret"></b></a>
									<ul class="dropdown-menu" style="border-radius: 30px; width: 230px; background-color: gray">
										<li>
											<a href="profile.php?patientId=<?php echo $userRow['icPatient']; ?>" style="margin-left: 85px" class="nav-link"> Profile</a>

										</li>

										<li>
											<a href="patientapplist.php?patientId=<?php echo $userRow['icPatient']; ?>"style="margin-left: 55px" class="nav-link"><i class="glyphicon glyphicon-file"></i> Appointment list</a>
                    </li>
										<li class="divider"></li>
										<li>
											<a href="patientlogout.php?logout" style="margin-left: 80px" class="nav-link"> Log Out</a>
										</li>
									</ul>
								</li>

	        </ul>
	      </div>
	    </div>
	  </nav>

  <!-- END nav -->

  <section class="home-slider owl-carousel">
    <div class="slider-item bread-item" style="background-image: url('../assets/images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container" data-scrollax-parent="true">
        <div class="row slider-text align-items-end">
          <div class="col-md-7 col-sm-12 ftco-animate mb-5">
            <p class="breadcrumbs" data-scrollax=" properties: { translateY: '70%', opacity: 1.6}"><span class="mr-2"><a href="patient.php">Home</a></span> <span>Services</span></p>
            <h1 class="mb-3" data-scrollax=" properties: { translateY: '70%', opacity: .9}">Well Experienced Doctors</h1>
            <h3 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Hi <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?>. Make appointment today!</h3>
            <p><a href="appointment.php" class="btn btn-primary px-4 py-3">Make an Appointment</a></p>
          </div>
        </div>
      </div>
    </div>
  </section>

	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center mb-5 pb-5">
				<div class="col-md-7 text-center heading-section ftco-animate">
					<h2 class="mb-3">Meet Our Experience Dentist and Staff</h2>
					<p>Far far away, near in SM MOLINO , far from the countries Manila and Imus City, there live the blind texts.</p>
				</div>
			</div>
			<div class="row">

				<?php
				include '../assets/conn/dbconnect.php';
				$staffId = "";
				$qwer = mysqli_query($con, "SELECT * FROM staff");
				while ($userRows = mysqli_fetch_array($qwer)) {




				echo "<div class='col-lg-3 col-md-6 d-flex mb-sm-4 ftco-animate'>";

				echo "<div class='staff'>";
				 echo "<div class='img mb-4' style='background-image: url(../doctor/assets/img/".$userRows['staff'].".jpg);'></div>";
					echo "<div class='info text-center'>";
						echo "<h3><a href='#'>".$userRows['staffFirstName']." ".$userRows['staffLastName']."</a></h3>";
						echo "<span class='position'>".$userRows['Position']."</span>";
						echo "<div class='text'>";
							echo	"<p>".$userRows['staffAddress']."</p>";
							echo	"<ul class='ftco-social'>";
								echo  "<li class='ftco-animate'><a href='#'><span class='icon-twitter'></span></a></li>";
								echo  "<li class='ftco-animate'><a href='#'><span class='icon-facebook'></span></a></li>";
								echo "<li class='ftco-animate'><a href='#'><span class='icon-instagram'></span></a></li>";
								echo "<li class='ftco-animate'><a href='#'><span class='icon-google-plus'></span></a></li>";
						 echo "</ul>";
					echo "</div>";
					echo "</div>";
				echo "</div>";
			echo "</div>";
			}
				?>

			</div>
			<div class="row  mt-5 justify-conten-center">
				<div class="col-md-8 ftco-animate">
					<p>Galvez Dental Clinic is a Dentistry Clinic in Bacoor, Cavite. The clinic is visited by doctors like Dr. Maria Mercedes M. Galvez.</p>
				</div>
			</div>
		</div>
	</section>


	<section class="ftco-section ftco-counter img" id="section-counter" style="background-image: url(../assets/images/bg_1.jpg);" data-stellar-background-ratio="0.5">
		<div class="container">
			<div class="row d-flex align-items-center">
				<div class="col-md-3 aside-stretch py-5">
					<div class=" heading-section heading-section-white ftco-animate pr-md-4">
						<h2 class="mb-3">Achievements</h2>
						<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
					</div>
				</div>
				<div class="col-md-9 py-5 pl-md-5">
					<div class="row">
						<div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
							<div class="block-18">
								<div class="text">
									<strong class="number" data-number="14">0</strong>
									<span>Years of Experience</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


<?php include 'footer.php'; ?>
