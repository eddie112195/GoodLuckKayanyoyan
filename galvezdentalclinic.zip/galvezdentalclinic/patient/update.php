<?php

if (isset($_POST['update'])) {

$Username = $_POST['Username'];
$patientFirstName = $_POST['patientFirstName'];
$patientLastName = $_POST['patientLastName'];
$patientMaritialStatus = $_POST['patientMaritialStatus'];
$patientDOB = $_POST['patientDOB'];
$patientAddress = $_POST['patientAddress'];
$patientGender = $_POST['patientGender'];
$patientPhone = $_POST['patientPhone'];
$patientEmail = $_POST['patientEmail'];
$icPatient = $_POST['icPatient'];
// mysqli_query("UPDATE blogEntry SET content = $udcontent, title = $udtitle WHERE id = $id");
mysqli_query($con, "UPDATE patient SET Username = '$Username', patientFirstName='$patientFirstName', patientLastName='$patientLastName', patientAddress='$patientAddress', patientGender = '$patientGender', patientMaritialStatus ='$patientMaritialStatus', patientPhone = '$patientPhone', patientEmail='$patientEmail' WHERE icPatient = $icPatient");
?>
<script type="text/javascript">
alert('Your profile are updated');
header( 'Location: profile.php' );
</script>
<?php

}
?>
