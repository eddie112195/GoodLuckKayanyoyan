<?php
session_start();
// include_once '../connection/server.php';
include_once '../assets/conn/dbconnect.php';

if(!isset($_SESSION['patientSession']))
{
header("Location: ../index.php");
}
include 'update.php';
$usersession = $_SESSION['patientSession'];
$res=mysqli_query($con, "SELECT * FROM patient WHERE icPatient=".$_SESSION['patientSession']);
$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);

?>

<?php
$male="";
$female="";
if ($userRow['patientGender']=='male') {
$male = "checked";
}elseif ($userRow['patientGender']=='female') {
$female = "checked";
}
$single="";
$married="";
$separated="";
$divorced="";
$widowed="";
if ($userRow['patientMaritialStatus']=='single') {
$single = "checked";
}elseif ($userRow['patientMaritialStatus']=='married') {
$married = "checked";
}elseif ($userRow['patientMaritialStatus']=='separated') {
$separated = "checked";
}elseif ($userRow['patientMaritialStatus']=='divorced') {
$divorced = "checked";
}elseif ($userRow['patientMaritialStatus']=='widowed') {
$widowed = "checked";
}
?>
<?php include 'header.php'; ?>
<!-- END nav -->
<section class="home-slider owl-carousel">
 <div class="slider-item" style="background-image: url('../assets/images/bg_1.jpg');">
	 <div class="overlay"></div>
	 <div class="container">
		 <div class="row slider-text align-items-center" data-scrollax-parent="true">
			 <div class="col-md-6 col-sm-12 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
				 <?php if ($userRow['patientMaritialStatus']=="") {
	 // <!-- / notification start -->
	 echo "<div class='row'>";
		 echo "<div class='col-lg-12'>";
			 echo "<div class='alert alert-danger alert-dismissable'><h4>";
				 echo "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
				 echo " <i class='fa fa-info-circle'></i>  <strong>Please complete your profile first.</strong>" ;
			 echo "  </div>";
		 echo "</div>";
		 // <!-- notification end -->

		 } else {
		 }
		 ?>
				 <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Hi <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?>. Make appointment today!</h1>
				 <p class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">A Galvez Dental Clinic flows by their place and supplies it with the necessary regelialia.</p>
				 <p data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><a href="appointment.php" class="btn btn-primary px-4 py-3">Make an Appointment</a></p>
			 </div>
		 </div>
	 </div>
 </div>

 <div class="slider-item" style="background-image: url('../assets/images/bg_2.jpg');">
	 <div class="overlay"></div>
	 <div class="container">
		 <div class="row slider-text align-items-center" data-scrollax-parent="true">
			 <div class="col-md-6 col-sm-12 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
				 <?php if ($userRow['patientMaritialStatus']=="") {
	 // <!-- / notification start -->
	 echo "<div class='row'>";
		 echo "<div class='col-lg-12'>";
			 echo "<div class='alert alert-danger alert-dismissable'><h4>";
				 echo "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
				 echo " <i class='fa fa-info-circle'></i>  <strong>Please complete your profile first.</strong>" ;
			 echo "  </div>";
		 echo "</div>";
		 // <!-- notification end -->

		 } else {
		 }
		 ?>
				 <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Hi <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?>. Make appointment today!</h1>
				 <p class="mb-4">A Galvez Dental Clinic flows by their place and supplies it with the necessary regelialia.</p>
					<p><a href="appointment.php" class="btn btn-primary px-4 py-3">Make an Appointment</a></p>
			 </div>
		 </div>
	 </div>
 </div>
</section>		<!-- navigation -->

		<section class="ftco-intro">
 		 <div class="container">
 			 <div class="row no-gutters">
 				 <div class="col-md-12 color-1 p-4" style="border-radius: 20px">
 					 <div class="row">

  						<div class="col-md-3 col-sm-3">

								<div class="user-wrapper">
									<?php if ($userRow['patientGender'] == 'male') {
										$profile = "male.jpeg";
									}else{
										$profile = "female.jpg";
									}

	 								echo "<img src='assets/img/".$profile."' class='img-responsive' style='width: 200px; margin-left: 60px;  border-radius: 10px 10px 0px 0px' />";
									?>
	 								<div class="description"style="width: 200px; margin-left: 60px; border-radius: 0px 0px 10px 10px">
	 									<h4><?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?></h4>
	 									<h5> <strong> Website Designer </strong></h5>
	 									<p>
	 											Cavite State University Imus Campus
	 									</p>
	 									<?php include 'profileupdate.php'; ?>
	 									<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Update Profile</button>
	 								</div>
	 							</div>
	 							<hr />

	 						</div>

						<div class="col-md-9 col-sm-9  user-wrapper">
							<div class="description">
								<h3> <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?> </h3>
								<hr />

								<div class="panel panel-default">
									<div class="panel-body">


										<table class="table table-user-information" align="center">
											<tbody>


												<tr>
													<td>PatientMaritialStatus</td>
													<td><?php echo $userRow['patientMaritialStatus']; ?></td>
												</tr>
												<tr>
													<td>PatientDOB</td>
													<td><?php echo $userRow['patientDOB']; ?></td>
												</tr>
												<tr>
													<td>PatientGender</td>
													<td><?php echo $userRow['patientGender']; ?></td>
												</tr>
												<tr>
													<td>PatientAddress</td>
													<td><?php echo $userRow['patientAddress']; ?>
													</td>
												</tr>
												<tr>
													<td>PatientPhone</td>
													<td><?php echo $userRow['patientPhone']; ?>
													</td>
												</tr>
												<tr>
													<td>PatientEmail</td>
													<td><?php echo $userRow['patientEmail']; ?>
													</td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>

							</div>

						</div>
					</div>
					<!-- USER PROFILE ROW END-->
					<!-- end -->
					<div class="col-md-4">

						<!-- Large modal -->

						<!-- Modal -->
						<?php include_once 'update.php'; ?>
						<?php include 'profileupdate.php'; ?>
							<br /><br/>
						</div>

					</div>
					<!-- ROW END -->
				</section>
				<!-- SECTION END -->
			</div>
			<!-- CONATINER END -->
			<?php include 'footer.php'; ?>
						 <!-- USER PROFILE ROW END-->
						 <!-- end -->
						<script src="assets/js/jquery-1.12.4.min.js"></script>
						<script src="assets/js/kendo.all.min.js"></script>

			<script type="text/javascript">
														$(function () {
														$('#patientDOB').datetimepicker();
														});
														</script>
		</body>
	</html>
