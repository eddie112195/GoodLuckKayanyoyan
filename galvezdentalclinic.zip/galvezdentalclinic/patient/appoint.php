<?php
include '../assets/conn/dbconnect.php';

if (isset($_POST['appointment'])) {
$appId = "";
$patientIc = mysqli_real_escape_string($con, $_POST['patientIc']);
$appToday = date("Y-m-d");
$appDate = mysqli_real_escape_string($con, $_POST['date']);
$startTime = mysqli_real_escape_string($con, $_POST['startTime']);
$appService = mysqli_real_escape_string($con,$_POST['services']);
$comment = mysqli_real_escape_string($con,$_POST['comment']);
$endTime = mysqli_real_escape_string($con, $_POST['endTime']);
$status = "process";
$status1 = "unread";
$price ="";
$errors = array();

$quer =mysqli_query($con, "SELECT * FROM services WHERE servicesId = '$appService'");
$ar = mysqli_fetch_array($quer);
$appService = $ar['Services'];
$price = $ar['Price'];

$query = mysqli_query($con,"SELECT * FROM appointment WHERE patientIc ='$patientIc'");
while($arrayRows = mysqli_fetch_array($query)){

if($arrayRows['appDate'] === $appDate){
array_push($errors, "You only have one fare Day to appoint.");
?>
<script type="text/javascript">
alert('You only have one appointment fare Day.');

</script>
<?php
}
}
$que = mysqli_query($con, "SELECT * FROM appointment WHERE patientIc = '$patientIc' AND appDate ='$appDate' AND startTime ='$startTime'");
while ($array = mysqli_fetch_array($que)){
	if ($array['appDate'] === $appDate && $array['startTime'] === $startTime) {
		?>
		<script type="text/javascript">
		alert('The date and time that you pick are already taken.');

		</script>
		<?php
	}
}
if ($startTime === '12:00 PM') {
	?>
	<script type="text/javascript">
	alert('The time you select is Lunch Break.');

	</script>
	<?php
}

if(count($errors) == 0){
$query = "INSERT INTO appointment (  patientIc , appToday, appDate, startTime, endTime, appService , Price, appComment, status, status1  )
VALUES ( '$patientIc', '$appToday', '$appDate', '$startTime', '$endTime', '$appService', '$price', '$comment', '$status', '$status1') ";

//update table appointment schedule

$result = mysqli_query($con,$query);
// echo $result;

if( $result )
{
?>
<script type="text/javascript">
alert('Appointment made successfully.');

</script>
<?php
header('Location: patientapplist.php');
}
}
}



//dapat dari generator end

?>
