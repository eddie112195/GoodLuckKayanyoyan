<?php
session_start();
include_once '../assets/conn/dbconnect.php';
include 'update.php';


$session= $_SESSION['patientSession'];
// $appid=null;
// $appdate=null;
$update = false;
if (isset($_GET['date'])) {
	$appDate =$_GET['date'];
	$appid = $_GET['appid'];
}
// on b.icPatient = a.icPatient
$res = mysqli_query($con,"SELECT * FROM patient
WHERE icPatient='$session'");
$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);
$appDate = "";
$price = "";
$disable = "";
//INSERT
?>
<?php
$male="";
$female="";
if ($userRow['patientGender']=='male') {
$male = "checked";
}elseif ($userRow['patientGender']=='female') {
$female = "checked";
}
$single="";
$married="";
$separated="";
$divorced="";
$widowed="";
if ($userRow['patientMaritialStatus']=='single') {
$single = "checked";
}elseif ($userRow['patientMaritialStatus']=='married') {
$married = "checked";
}elseif ($userRow['patientMaritialStatus']=='separated') {
$separated = "checked";
}elseif ($userRow['patientMaritialStatus']=='divorced') {
$divorced = "checked";
}elseif ($userRow['patientMaritialStatus']=='widowed') {
$widowed = "checked";
}
?>
<?php include 'appoint.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Galvez Dental Clinic</title>
    <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="../assets/css/open-iconic-bootstrap.min.css">
		<link rel="stylesheet" href="../assets/css/animate.css">

		<link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">
		<link rel="stylesheet" href="../assets/css/magnific-popup.css">

		<link rel="stylesheet" href="../assets/css/aos.css">

		<link rel="stylesheet" href="../assets/css/ionicons.min.css">

		<link rel="stylesheet" href="../assets/css/bootstrap-datepicker.css">
		<link rel="stylesheet" href="../assets/css/jquery.timepicker.css">

		<link rel="stylesheet" href="../assets/css/flaticon.css">
		<link rel="stylesheet" href="../assets/css/icomoon.css">
		<link rel="stylesheet" href="../assets/css/style.css">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700" rel="stylesheet">
				<link rel="stylesheet" href="assets/css/kendo.common.min.css">
<link rel="stylesheet" href="assets/css/kendo.rtl.min.css">
<link rel="stylesheet" href="assets/css/kendo.silver.min.css">
<link rel="stylesheet" href="assets/css/kendo.mobile.all.min.css">
<link rel="stylesheet" href="assets/css/kendo.common-material.min.css">
<link rel="stylesheet" href="assets/css/kendo.material.min.css">
<link rel="stylesheet" href="assets/css/kendo.material.mobile.min.css">
  </head>
  <body>

		<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="patient.php">Galvez <span>Dental Clinic</span></a>
          <a href="patientapplist.php" class="navbar-brand">Appointment List</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
	          <li class="nav-item"><a href="doctors.php" class="nav-link">Doctors</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
            <li class="dropdown">

              <?php
              $queryy = mysqli_query($con,"SELECT a.*, b.*
                                      FROM patient a
                                      JOIN message b
                                      On b.PatientIc = a.icPatient WHERE b.status = 'unread'");

                  $arrayy = mysqli_fetch_all($queryy);
                if (count($arrayy) > 0) {
                ?>
                   <a class="nav-link" id="dropdown01" data-toggle= "dropdown" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i class="fa fa-bell"></i> Notification</i>
                     <span class="badge badge-light" style="background-color: red; font-size: 12px; color: white; border-radius: 50%!important"><?php echo count($arrayy); ?></span>
                   <?php
                 }
                  ?>
                     </a>
                   <ul class="dropdown-menu" style="margin-right: 40px">
                       <?php
                           if (count($arrayy) > 0) {
                             foreach ($queryy as $qww) {
                           ?>
                                <li>
                               <a style="
                                      <?php if($qww['status'] =='unread'){
                               echo "font-weight: bold; width: 200px";
                             }
                               ?>"
                                class="dropdown-item" href="view.php?patientId=<?php echo $qww['messageId']; ?>"><br/>
                                <i class="fa fa-fw fa-user"></i>
                                 <?php echo $qww['timeDate']; ?> <br><?php echo $qww['staff']; ?> of clinic.
                            <br>
                               <?php echo $qww['message']; ?>
                               <h6>Message</h6>
                               </a>
                             </li>

                           <?php
                           }
                         }


                        ?>
                   </ul>
                   </li>
              <i class="nav-link">Hi </i>
              <li class="dropdown nav-item cta">
									<a href="#" class="nav-link" data-toggle="dropdown"><i class="fa fa-user"></i>   <?php echo $userRow['patientFirstName']; ?><b class="caret"></b></a>
									<ul class="dropdown-menu" style="border-radius: 30px; width: 230px; background-color: gray">
										<li>
											<a href="profile.php?patientId=<?php echo $userRow['icPatient']; ?>" style="margin-left: 85px" class="nav-link"> Profile</a>

										</li>

										<li>
											<a href="patientapplist.php?patientId=<?php echo $userRow['icPatient']; ?>"style="margin-left: 55px" class="nav-link"><i class="glyphicon glyphicon-file"></i> Appointment list</a>
                    </li>
										<li class="divider"></li>
										<li>
											<a href="patientlogout.php?logout" style="margin-left: 80px" class="nav-link"> Log Out</a>
										</li>
									</ul>
								</li>

	        </ul>
	      </div>
	    </div>
	  </nav>

		<!-- navigation -->

		<section class="home-slider owl-carousel">
 		 <div class="slider-item" style="background-image: url('../assets/images/bg_1.jpg');">
 			 <div class="overlay"></div>
 			 <div class="container">
 				 <div class="row slider-text align-items-center" data-scrollax-parent="true">
 					 <div class="col-md-6 col-sm-12 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
 						 <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Hi <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?>. Make appointment today!</h1>
 						 <p class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">A Galvez Dental Clinic flows by their place and supplies it with the necessary regelialia.</p>

 					 </div>
 				 </div>
 			 </div>
 		 </div>

 		 <div class="slider-item" style="background-image: url('../assets/images/bg_2.jpg');">
 			 <div class="overlay"></div>
 			 <div class="container">
 				 <div class="row slider-text align-items-center" data-scrollax-parent="true">
 					 <div class="col-md-6 col-sm-12 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
 						 <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Hi <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?>. Make appointment today!</h1>
 						 <p class="mb-4">A Galvez Dental Clinic flows by their place and supplies it with the necessary regelialia.</p>

 					 </div>
 				 </div>
 			 </div>
 		 </div>
 	 </section>
	 <section class="ftco-intro">
		 <div class="container">
			 <div class="row no-gutters">
				 <div class="col-md-12 color-1 p-4" style="border-radius: 20px">
					 <div class="row">

 						<div class="col-md-3 col-sm-3">

 							<div class="user-wrapper">
								<?php if ($userRow['patientGender'] == 'male') {
									$profile = "male.jpeg";
								}else{
									$profile = "female.jpg";
								}

 								echo "<img src='assets/img/".$profile."' class='img-responsive' style='width: 200px; margin-left: 60px;  border-radius: 10px 10px 0px 0px' />";
								?>
 								<div class="description"style="width: 200px; margin-left: 60px; border-radius: 0px 0px 10px 10px">
 									<h4><?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?></h4>
 									<h5> <strong> Website Designer </strong></h5>
 									<p>
 											Cavite State University Imus Campus
 									</p>
 									<?php include 'profileupdate.php'; ?>
 									<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Update Profile</button>
 								</div>
 							</div>
 							<hr />

 						</div>

 												<div class="col-md-9 col-sm-9  user-wrapper">

 							<div class="description">


 								<div class="panel panel-default" style="background-color: grey; border-radius: 20px; padding: 12px">
									<?php if ($userRow['patientMaritialStatus']=="") {
						// <!-- / notification start -->
							echo "<div class='alert alert-danger' style='width: 100%'>Please complete your profile first to make an appointment</div>" ;
								$disable ="disabled";
							// <!-- notification end -->

							} else {
							}
							?>

 									<div class="panel-body">
										<?php include ('errors.php'); ?>
 										<form class="form" role="form" action="appointment.php" method="POST" accept-charset="UTF-8">

 											<div class="panel panel-default">
 												<div class="panel-heading"><h4>Patient Information</div>
 												<div class="panel-body">

 													 <h6>Patient Name: <?php echo $userRow['patientFirstName'] ?> <?php echo $userRow['patientLastName'] ?><br>
 													 Patient IC: <input type="text" name="patientIc" value="<?php echo $userRow['icPatient'] ?>"> <br>
 													 Contact Number: <?php echo $userRow['patientPhone'] ?><br>
 													 Address: <?php echo $userRow['patientAddress'] ?>
 												</div>
 											</div>

 											<div class="panel panel-default">
												<hr/>
 												<div class="panel-body">
													<div class="col-lg-12 mx-auto">
 													<div class="col-md-4">
 														<h5>Mon-Sat.</h5>
 															<h6>09:00 AM-12:00 PM</h6>
 															<h6>01:30 PM-06:00 PM</h6>
 													</div>
 														<div class="col-md-4">
 															<h5>Lunch Break</h5>
 															<h6>12:00 AM-01:30 PM</h6>
 														</div>
													</div>
 														<hr/>

 														<div class="col-lg-12 mx-auto">
 													<h4>Date Now: <?php echo date("Y-m-d") ?></h4>
													<div class="panel-heading">Appointment</div><br>
 												</div>

												<div class="col-md-12 d-flex align-self-stretch ftco-animate">
												<div class="col-md-4">
 													Date: <br>
 													<input class="control" id="datepicker" name="date" onchange="showUser(this.value)" required <?php echo $disable; ?>/>
 																</div>
																<div class="col-md-4">

 																		Start Time :
 																		<br>
 																<input type="text" class="control" id = "start" name="startTime" style="border-radius: 20px" required <?php echo $disable; ?>/>
 															</div>
 															<div class="col-md-3">
 																	End Time :
 																	<br>
 																<input class="control" id = "end" name="endTime" style="border-radius: 12px" required <?php echo $disable; ?>/>
 															</div>
														</div>
 																<div class="col-lg-12 col-sm-12  user-wrapper" style="margin: 0px auto"><br/>
 																	<script>
 						function showUser(str) {

 						if (str == "") {
 						document.getElementById("txtHint").innerHTML = "No data to be shown";
 						return;
 						} else {
 						if (window.XMLHttpRequest) {
 						// code for IE7+, Firefox, Chrome, Opera, Safari
 						xmlhttp = new XMLHttpRequest();
 						} else {
 						// code for IE6, IE5
 						xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
 						}
 						xmlhttp.onreadystatechange = function() {
 						if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
 						document.getElementById("txtHint").innerHTML = xmlhttp.responseText;
 						}
 						};
 						xmlhttp.open("GET","getschedule.php?q="+str,true);
 						console.log(str);
 						xmlhttp.send();
 						}
 						}
 						</script>
 						<div id="txtHint"><b> </b></div>
 					</div>

 												</div>
 												</div>

 											</div>
												<div class="form-group" style="width: 100%">
													<label for="recipient-name" class="control-label">Service : </label>
													<?php include 'offer.php'; ?>
													<a href="#" data-toggle="modal" data-target="#myModal2"><button type="submit" class="btn btn-primary" style="border-radius : 10px">Click here to see the prices</button></a><br>
													<br><select name="services" class = "form-control" style="border-radius: 20px" <?php echo $disable; ?>>
														<option value="">Services</option>
 											<?php include 'offer.php'; ?>
 											<?php
 											 	$rew = mysqli_query($con, "SELECT * FROM services WHERE servicesId");
 												while ($appoint = mysqli_fetch_array($rew)){

 											 ?><br/>
 														<option value="<?php echo $appoint['servicesId']; ?>"><?php echo $appoint['Services']; ?></option>
																											<?php } ?>
												</select>

 											</div>


 											<div class="form-group">
 												<label for="message-text" class="control-label">Note :</label>
 												<textarea class="form-control" name="comment" required></textarea>
 											</div>
 											<div class="form-group">
 												<input type="submit" name="appointment" id="submit" class="btn btn-primary" style="border-radius: 20px" value="Make Appointment">
 											</div>
 										</form>
 									</div>
 								</div>

 							</div>

 						</div>
 					</div>

				 </div>
			 </div>
		 </div>
	 </section>
	 <br>
	 <?php include 'footer.php'; ?>
					<!-- USER PROFILE ROW END-->
					<!-- end -->
				 <script src="assets/js/jquery-1.12.4.min.js"></script>
				 <script src="assets/js/kendo.all.min.js"></script>

				<!-- Include all compiled plugins (below), or include individual files as needed -->
			<script>
				$(document).ready(function() {
            $("#datepicker").kendoDatePicker({
							format: 'yyyy-MM-dd',
                disableDates: ["su"],
                min: new Date()
            });
					});
						</script>

						<script>
						$(document).ready(function() {
							function startChange() {
								var startTime = start.value();

								if (startTime) {
									startTime = new Date(startTime);

									end.max(startTime);

									startTime.setMinutes(startTime.getMinutes() + this.options.interval);

									end.min(startTime);
									end.value(startTime);
								}
							}
							var start = $("#start").kendoTimePicker({
								interval: 60,
								change: startChange
							}).data("kendoTimePicker");

							var end = $("#end").kendoTimePicker().data("kendoTimePicker");

							start.min("9:00 AM");
							start.max("5:00 PM");


							end.min("10:00 AM");
							end.min("6:00 PM");
						});
						</script>
				</body>
			</html>
