<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style=" border-radius : 15px; width:600px">
      <div class="modal-header">

        <h4 class="modal-title" id="myModalLabel">Profile</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <!-- form start -->
        <form action="<?php $_PHP_SELF ?>" method="post" >
          <table class="table table-user-information" style="color: black">
            <tbody>
              <tr>
                <td>icPatient :</td>
                <td><input type="hidden" name="icPatient" value="<?php echo $userRow['icPatient']; ?>"><?php echo $userRow['icPatient']; ?></td>
              </tr>
              <tr>
                <td>Username :</td>
                <td><input type="text" class="form-control" name="Username" value="<?php echo $userRow['Username']; ?>"  required/></td>
              </tr>
              <tr>
                <td>First Name :</td>
                <td><input type="text" class="form-control" name="patientFirstName" value="<?php echo $userRow['patientFirstName']; ?>"  required/></td>
              </tr>
              <tr>
                <td>Last Name :</td>
                <td><input type="text" class="form-control" name="patientLastName" value="<?php echo $userRow['patientLastName']; ?>"  required/></td>
              </tr>

              <!-- radio button -->
              <tr>
                <td>Maritial Status :</td>
                <td required/>
                  <div class="radio">
                    <label><input type="radio" name="patientMaritialStatus" value="single" <?php echo $single; ?>>Single</label>
                  </div>
                  <div class="radio">
                    <label><input type="radio" name="patientMaritialStatus" value="married" <?php echo $married; ?>>Married</label>
                  </div>
                  <div class="radio">
                    <label><input type="radio" name="patientMaritialStatus" value="separated" <?php echo $separated; ?>>Separated</label>
                  </div>
                  <div class="radio">
                    <label><input type="radio" name="patientMaritialStatus" value="divorced" <?php echo $divorced; ?>>Divorced</label>
                  </div>
                  <div class="radio">
                    <label><input type="radio" name="patientMaritialStatus" value="widowed" <?php echo $widowed; ?>>Widowed</label>
                  </div>
                </td>
              </tr>
              <!-- radio button end -->
              <tr>
                <td>Date of Birth</td>
                <!-- <td><input type="text" class="form-control" name="patientDOB" value="<?php echo $userRow['patientDOB']; ?>"  requi/></td> -->
                <td>
                  <div class="form-group ">

                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar">
                        </i>
                      </div>
                      <input class="form-control" id="patientDOB" name="patientDOB" placeholder="MM/DD/YYYY" type="text" value="<?php echo $userRow['patientDOB']; ?>"required/>
                    </div>
                  </div>
                </td>

              </tr>
              <!-- radio button -->
              <tr>
                <td>Gender</td>
                <td required/>
                  <div class="radio">
                    <label><input type="radio" name="patientGender" value="male" <?php echo $male; ?>>Male</label>
                  </div>
                  <div class="radio">
                    <label><input type="radio" name="patientGender" value="female" <?php echo $female; ?>>Female</label>
                  </div>
                </td>
              </tr>
              <!-- radio button end -->

              <tr>
                <td>Phone number</td>
                <td><input type="text" class="form-control" name="patientPhone" value="<?php echo $userRow['patientPhone']; ?>"  required/></td>
              </tr>
              <tr>
                <td>Email</td>
                <td><input type="text" class="form-control" name="patientEmail" value="<?php echo $userRow['patientEmail']; ?>"  required/></td>
              </tr>
              <tr>
                <td>Address</td>
                <td><textarea class="form-control" name="patientAddress"  required/><?php echo $userRow['patientAddress']; ?></textarea></td>
              </tr>
              <tr>
                <td>
                  <input type="submit" name="update" id ="update" class="btn btn-info" value="Update Info"></td>
                </tr>
              </tbody>

            </table>



          </form>
          <!-- form end -->
        </div>

      </div>
    </div>
  </div>
