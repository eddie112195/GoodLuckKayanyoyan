<?php
session_start();
include_once '../assets/conn/dbconnect.php';
if(!isset($_SESSION['patientSession']))
{
header("Location: ../index.php");
}

$usersession = $_SESSION['patientSession'];


$res=mysqli_query($con,"SELECT * FROM patient WHERE icPatient='$usersession'");

if ($res===false) {
	echo mysql_error();
}

$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);
?>
<?php
$update12 = false;
if (isset($_GET['edit'])) {
  $update12 = true;
}
if (isset($_POST['Message'])) {

    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $subject = mysqli_real_escape_string($con, $_POST['subject']);
    $message = mysqli_real_escape_string($con, $_POST['message']);
    $status ="process";
    $query =  "INSERT INTO information ( Name, Email, Subject, Message, status)
     VALUES ( '$name','$email', '$subject', '$message', '$status') ";
    $result = mysqli_query($con, $query);
     if( $result ){
?>
<script type="text/javascript">
alert('Your message sent.');
</script>
<?php
}
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Galvez Dental Clinic</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/animate.css">

    <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../assets/css/magnific-popup.css">

    <link rel="stylesheet" href="../assets/css/aos.css">

    <link rel="stylesheet" href="../assets/css/ionicons.min.css">

    <link rel="stylesheet" href="../assets/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../assets/css/jquery.timepicker.css">


    <link rel="stylesheet" href="../assets/css/flaticon.css">
    <link rel="stylesheet" href="../assets/css/icomoon.css">
    <link rel="stylesheet" href="../assets/css/style.css">
  </head>
  <body>

	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="patient.php">Galvez <span>Dental Clinic</span></a>
          <a href="patientapplist.php" class="navbar-brand">Appointment List</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="patient.php" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
	          <li class="nav-item"><a href="doctors.php" class="nav-link">Doctors</a></li>
	          <li class="nav-item active"><a href="contact.php" class="nav-link">Contact</a></li>
              <i class="nav-link">Hi </i>
              <li class="dropdown nav-item cta">
									<a href="#" class="nav-link" data-toggle="dropdown"><i class="fa fa-user"></i>   <?php echo $userRow['patientFirstName']; ?><b class="caret"></b></a>
									<ul class="dropdown-menu" style="border-radius: 30px; width: 230px; background-color: gray">
										<li>
											<a href="profile.php?patientId=<?php echo $userRow['icPatient']; ?>" style="margin-left: 85px" class="nav-link"> Profile</a>

										</li>

										<li>
											<a href="patientapplist.php?patientId=<?php echo $userRow['icPatient']; ?>"style="margin-left: 55px" class="nav-link"><i class="glyphicon glyphicon-file"></i> Appointment list</a>
                    </li>
										<li class="divider"></li>
										<li>
											<a href="patientlogout.php?logout" style="margin-left: 80px" class="nav-link"> Log Out</a>
										</li>
									</ul>
								</li>

	        </ul>
	      </div>
	    </div>
	  </nav>

    <!-- END nav -->
    <section class="home-slider owl-carousel">
      <div class="slider-item bread-item" style="background-image: url('../assets/images/bg_1.jpg');" data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container" data-scrollax-parent="true">
          <div class="row slider-text align-items-end">
            <div class="col-md-7 col-sm-12 ftco-animate mb-5">
              <p class="breadcrumbs" data-scrollax=" properties: { translateY: '70%', opacity: 1.6}"><span class="mr-2"><a href="patient.php">Home</a></span> <span>Blog</span></p>
              <h1 class="mb-3" data-scrollax=" properties: { translateY: '70%', opacity: .9}">Contact Us</h1>
              <h3 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Hi <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?>. Make appointment today!</h3>
              <p><a href="appointment.php" class="btn btn-primary px-4 py-3">Make an Appointment</a></p>
            </div>
          </div>
        </div>
      </div>
    </section>

		<section class="ftco-section contact-section ftco-degree-bg">
      <div class="container">
        <div class="row d-flex mb-5 contact-info">
          <div class="col-md-12 mb-4">
            <h2 class="h4">Contact Information</h2>
          </div>
          <div class="w-100"></div>
          <div class="col-md-3">
            <p><span>Address:</span>At (Address:) Unit 4 Shopwise Molino road, Molino 4 Bacoor, Cavite(beside SM Molino)</p>
          </div>
          <div class="col-md-3">
            <p><span>Phone:</span> <a href="tel://(046)4843217">(046) 484 3217</a></p>
          </div>
          <div class="col-md-3">
            <p><span>Email:</span> <a href="mailto:info@yoursite.com">GalvezDentalClinic@gmail.com</a></p>
          </div>
          <div class="col-md-3">
            <p><span>Website</span> <a href="#">GalvezDentalClinic.com</a></p>
          </div>
        </div>
        <div class="row block-9">
          <div class="col-md-6 pr-md-5">
            <form action="contact.php" method="post">
              <div class="form-group">
                <input type="text" class="form-control" name="name" placeholder="Your Name">
              </div>
              <div class="form-group">
                <input type="email" class="form-control" name="email" placeholder="Your Email">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" placeholder="Subject">
              </div>
              <div class="form-group">
                <textarea  id="" cols="30" rows="7" name="message" class="form-control" placeholder="Message"></textarea>
              </div>
              <div class="form-group">
                <button type="submit" name="Message" class="btn btn-primary py-3 px-5">Send Message</buton>
              </div>
            </form>
          </div>

          <div class="col-md-6" id="map"></div>
        </div>
      </div>
    </section>

  <?php include 'footer.php'; ?>
