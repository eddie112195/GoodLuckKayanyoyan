<?php
session_start();
include_once '../assets/conn/dbconnect.php';
if(!isset($_SESSION['patientSession']))
{
header("Location: ../index.php");
}

$usersession = $_SESSION['patientSession'];


$res=mysqli_query($con,"SELECT * FROM patient WHERE icPatient='$usersession'");

if ($res===false) {
	echo mysql_error();
}

$Row=mysqli_fetch_array($res,MYSQLI_ASSOC);
?>


<?php
include_once '../assets/conn/dbconnect.php';
$session=$_SESSION[ 'patientSession'];

$res=mysqli_query($con, "SELECT a.*, b.*
	FROM patient a
	JOIN appointment b
		On a.icPatient = b.patientIc
		Order by appId desc");

	$userRow=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Galvez Dental Clinic</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/animate.css">

    <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../assets/css/magnific-popup.css">

    <link rel="stylesheet" href="../assets/css/aos.css">

    <link rel="stylesheet" href="../assets/css/ionicons.min.css">

    <link rel="stylesheet" href="../assets/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../assets/css/jquery.timepicker.css">


    <link rel="stylesheet" href="../assets/css/flaticon.css">
    <link rel="stylesheet" href="../assets/css/icomoon.css">
    <link rel="stylesheet" href="../assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="assets/css/datatables.min.css"/>
	  <link rel="stylesheet" type = "text/css" href="assets/css/buttons.datatables.min.css">
		<link rel="stylesheet" href="assets/css/font-awesome.min.css">

  </head>
  <body>

	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="patient.php">Galvez <span>Dental Clinic</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="patient.php" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
	          <li class="nav-item"><a href="doctors.php" class="nav-link">Doctors</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
              <i class="nav-link">Hi </i>
              <li class="dropdown nav-item cta">
									<a href="#" class="nav-link" data-toggle="dropdown"><i class="fa fa-user"></i>   <?php echo $userRow['patientFirstName']; ?><b class="caret"></b></a>
									<ul class="dropdown-menu" style="border-radius: 30px; width: 230px; background-color: gray">
										<li>
											<a href="profile.php?patientId=<?php echo $userRow['icPatient']; ?>" style="margin-left: 85px" class="nav-link"> Profile</a>

										</li>

										<li>
											<a href="patientapplist.php?patientId=<?php echo $userRow['icPatient']; ?>"style="margin-left: 55px" class="nav-link"><i class="glyphicon glyphicon-file"></i> Appointment list</a>
                    </li>
										<li class="divider"></li>
										<li>
											<a href="patientlogout.php?logout" style="margin-left: 80px" class="nav-link"> Log Out</a>
										</li>
									</ul>
								</li>

	        </ul>
	      </div>
	    </div>
	  </nav>
		<section class="home-slider owl-carousel">
			<div class="slider-item bread-item" style="background-image: url('../assets/images/bg_1.jpg');" data-stellar-background-ratio="0.5">
				<div class="overlay"></div>
				<div class="container" data-scrollax-parent="true">
					<div class="row slider-text align-items-end">
						<div class="col-md-7 col-sm-12 ftco-animate mb-5">
							<p class="breadcrumbs" data-scrollax=" properties: { translateY: '70%', opacity: 1.6}"><span class="mr-2"><a href="patient.php">Home</a></span> <span>Blog</span></p>
							<h1 class="mb-3" data-scrollax=" properties: { translateY: '70%', opacity: .9}">Your History of appoint</h1>
							<h3 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Hi <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?>. Make appointment today!</h3>
							<p><a href="appointment.php" class="btn btn-primary px-4 py-3">Make an Appointment</a></p>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- navigation -->
<!-- display appoinment start -->

<div class='container'>
<div class='row'>
<div class='page-header' style = 'padding: 12px'>
<h1>Your appointment list. </h1>
</div>
<div class='panel panel-primary'>
<div class='panel-heading'>List of Appointment</div>
<div class='panel-body'>
  <table id="data" class="table table-bordered table-striped" >
<thead>
<tr>
<th>Id</th>
<th>patientIc </th>
<th>LastName </th>
<th>scheduleDay </th>
<th>scheduleDate </th>
<th>startTime </th>
<th>endTime </th>
<th>Service </th>
<th>Price </th>
<th>Print </th>
</tr>
</thead>
<tbody>
<tr>
<?php

$res = mysqli_query($con, "SELECT *
		FROM patient a
		JOIN appointment b
		On a.icPatient = b.patientIc
		WHERE b.patientIc ='$session' Order By appId desc");

if (!$res) {
die("Error running $sql: " . mysqli_error());
}


while ($userRow = mysqli_fetch_array($res)) {
echo "<h6>";
echo "<td>" . $userRow['appId'] . "</td>";
echo "<td>" . $userRow['patientIc'] . "</td>";
echo "<td>" . $userRow['patientLastName'] . "</td>";
echo "<td>" . $userRow['appToday'] . "</td>";
echo "<td>" . $userRow['appDate'] . "</td>";
echo "<td>" . $userRow['startTime'] . "</td>";
echo "<td>" . $userRow['endTime'] . "</td>";
echo "<td>" . $userRow['appService'] . "</td>";
echo "<td>" . $userRow['Price'] . "</td>";
echo "<td><a href='invoice.php?appid=".$userRow['appId']."'><i class ='fa fa-print' style= 'font-size: 20px; color: black'></i></a> </td>";
echo "</h6>";
echo "</tr>";
}
echo "</tbody>";
echo "</table>";
?><br>
	</div>
</div>
</div>
</div>
<?php include 'footer.php'; ?>
<script type="text/javascript" src="assets/js/jquery-3.3.1.js"></script>
<script type="text/javascript" src="assets/js/datatables.min.js"></script>
<script type="text/javascript" src= "assets/js/datatable.js"></script>
<script type="text/javascript" src= "assets/js/buttons.print.min.js"></script>
<script type="text/javascript" src= "assets/js/jszip.min.js"></script>
<script type="text/javascript" src= "assets/js/pdfmake.min.js"></script>
<script type="text/javascript" src = "assets/js/buttons.html5.min.js"></script>
<!-- display appoinment end -->
<script type="text/javascript">
$(function() {
$(".delete").click(function(){
var element = $(this);
var appid = element.attr("id");
var info = 'id=' + appid;
if(confirm("Are you sure you want to delete this?"))
{
$.ajax({
type: "POST",
url: "deleteappointment.php",
data: info,
success: function(){
}
});
$(this).parent().parent().fadeOut(300, function(){ $(this).remove();});
}
return false;
});
});
</script>
<script>
$(document).ready(function() {
$('#data').DataTable( {
dom: 'Bfrtip',
buttons: [
		{extend:'copy', className: 'btn btn-primary'},
		{extend:'excel', className: 'btn btn-primary'},
		 {extend:'print', className: 'btn btn-primary'}
]
} );
} );
</script>

</body>
</html>
