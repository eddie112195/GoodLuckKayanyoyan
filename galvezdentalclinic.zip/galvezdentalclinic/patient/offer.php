<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="border-radius : 17px; width:600px">
                    <!-- modal content -->
                    <div class="modal-header">

                        <h3 class="modal-title" style="text-align: center; color: black"><span style="font-style: Bold">Services we offer</h3>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <!-- modal body start -->


                    <table class= "table table">
                      <thead>
                        <tr>
                            <th><h5>SERVICE</h5></th>
                            <th><h5>Price</h5></th>

                        </tr>
        <?php
        $result=mysqli_query($con,"SELECT * FROM services");
        while ($serviceRow=mysqli_fetch_array($result)){
          echo "<tbody>";
          echo "<tr>";

?>

           <td><h6 style="color: black"><?php echo $serviceRow['Services'];  ?></h6></td>
          <td><h6 style="color: black"><?php echo $serviceRow['Price'];  ?> </h6></td>
<?php
}

echo "</tbody>";
echo "</table>";
?>

                </div>
            </div>
        </div>
