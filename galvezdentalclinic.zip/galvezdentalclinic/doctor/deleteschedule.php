<?php
include '../assets/conn/dbconnect.php';
// Get the variables.
$doctorId = $_POST['ic'];
// echo $appid;

$delete = mysqli_query($con,"DELETE FROM staff WHERE id= $doctorId");
// if(isset($delete)) {
//    echo "YES";
// } else {
//    echo "NO";
// }



?>
