<?php
include_once '../assets/conn/dbconnect.php';
$staffIc = "";
$Username ="";
$Password = "";
$staffFirstName = "";
 $staffLastName = "";
$Position = "";
$staffPhone = "";

$staffId = 0;
if (isset($_POST['update'])) {
  $Username = mysqli_real_escape_string($con, $_POST['Username']);
  $Password = mysqli_real_escape_string($con, $_POST['Password']);
  $staffIc = mysqli_real_escape_string($con, $_POST['staffIc']);
      $staffFirstName = mysqli_real_escape_string($con, $_POST['staffFirstName']);
          $staffLastName = mysqli_real_escape_string($con, $_POST['staffLastName']);
              $staffPhone = mysqli_real_escape_string($con, $_POST['staffPhone']);
              $Position = mysqli_real_escape_string($con, $_POST['Position']);

                              $query =  "INSERT INTO staff ( icNumber, staff, password, staffFirstName, staffLastName, staffPhone, Position)
                               VALUES ( '$staffIc', '$Username', '$Password', '$staffFirstName', '$staffLastName', '$staffPhone', '$Position') ";
                              $result = mysqli_query($con, $query);
                               if( $result ){
                          ?>
                      <script type="text/javascript">
                          alert('New doctor Added.');
                      </script>
                      <?php
                      }

}



 ?>
