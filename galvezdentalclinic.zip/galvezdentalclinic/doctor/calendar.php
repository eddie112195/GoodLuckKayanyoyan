<html>
	<style>
		a,
		a:visited {
			color: #0A9297;
		}

		footer {
			text-align: left;
			margin: 1.6rem 0;
		}

		h1 {
			text-align: left;
		}

		.container {
			margin: 1.6rem auto;
			text-align: left;
		}

		.demo-picked {
			font-size: 1.2rem;
			text-align: left;
		}

		.demo-picked span {
			font-weight: bold;
		}
	</style>
</head>

<body>
	<div class="container">

		<div id="v-cal" style =  "width: 400px; margin-left: 12px">
			<div class="vcal-header">
				<button class="vcal-btn" data-calendar-toggle="previous" disable/>
					<svg height="24" version="1.1" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
						<path d="M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z" disable/></path>
					</svg>
				</button>

				<div class="vcal-header__label" data-calendar-label="month">
					March 2018
				</div>


				<button class="vcal-btn" data-calendar-toggle="next">
					<svg height="24" version="1.1" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
						<path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z"></path>
					</svg>
				</button>
			</div>
			<div class="vcal-week">
				<span>Mon</span>
				<span>Tue</span>
				<span>Wed</span>
				<span>Thu</span>
				<span>Fri</span>
				<span>Sat</span>
				<span>Sun</span>

			</div>
			<div class="vcal-body" data-calendar-area="month" id="datetimepicker11"></div>
		</div>

		<p class="demo-picked">
			Date picked:
			<span data-calendar-label="picked" onchange="showUser(this.value)"/></span>
		</p>
	<script src="dist/vanillaCalendar.js" onchange="showUser(this.value)" type="text/javascript" id = 'datetimepicker11'></script>
	<script>
		window.addEventListener('load', function () {
			vanillaCalendar.init({
				disablePastDays: true,
				 daysOfWeekDisabled: true
			});
		})
	</script>
	<script type="text/javascript">
  function rsfp_onSelectDate(date, type, args, calendar)
{
var dates = args[6];
var date = dates[6];
var year = date[6], month = date[1], day = date[2];

var d = new Date(year, month-6, day);
if (d.getDay() == 0 || d.getDay() == 1) {
alert('Please select a date that is different from Monday or Sunday!');
return false;
} else {
return true;
}
}
</script>

											 <div id="txtHint"><b> </b></div>
</body>
</html>
