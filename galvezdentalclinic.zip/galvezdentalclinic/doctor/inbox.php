<?php
session_start();
include_once '../assets/conn/dbconnect.php';
// include_once 'connection/server.php';
if(!isset($_SESSION['doctorSession']))
{
header("Location: ../index.php");
}
$usersession = $_SESSION['doctorSession'];
$res=mysqli_query($con,"SELECT * FROM admin WHERE Username ='$usersession'");
$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Welcome Dr <?php echo $userRow['doctorFirstName'];?> <?php echo $userRow['doctorLastName'];?></title>
        <!-- Bootstrap Core CSS -->
        <!-- <link href="assets/css/bootstrap.css" rel="stylesheet"> -->
        <link href="assets/css/material.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="assets/css/sb-admin.css" rel="stylesheet">
        <link href="assets/css/time/bootstrap-clockpicker.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <script src="assets/js/jquery-3.3.1.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="assets/css/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="assets/css/buttons.dataTables.min.css"/>
        <script type="text/javascript" src="assets/js/dataTables.buttons.min.js"></script>
        <script src="assets/js/dataTables.buttons.min.js" type="text/javascript"></script>
        <script src="assets/js/buttons.flash.min.js" type="text/javascript"></script>
        <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
        <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

        <!--Font Awesome (added because you use icons in your prepend/append)-->
        <link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

        <!-- Inline CSS based on choices in "Settings" tab -->
        <style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>

        <!-- Custom Fonts -->
    </head>
    <body>
        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="doctordashboard.php">Welcome Admin <?php echo $userRow['doctorFirstName'];?></a>
                </div>
                <!-- Top Menu Items -->

                <ul class="nav navbar-right top-nav">
                     <li class="dropdown">
                       <?php
                         $query = mysqli_query($con, "SELECT * FROM patient WHERE status = 'unread' Order By patientId desc");
                         $array = mysqli_fetch_all($query);?>
                            <a class="nav-link" id="dropdown01" data-toggle= "dropdown" placeholder="User" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i style="font-size: 20px" class="fa fa-bell"></i>

                                <?php
                                  if (count($array) > 0) {
                                  ?>
                              <span class="badge badge-light" style="background-color: red; font-size: 12px"><?php echo count($array); ?></span>
                            <?php
                          }
                           ?>
                         </a>
                            <ul class="dropdown-menu" style="margin-right: 40px">
                                <?php
                                    if (count($array) > 0) {
                                      foreach ($query as $qw) {

                                    ?>
                                    <li  style="margin: 0px auto; padding: auto">
                                        <a style="
                                               <?php if($qw['status'] =='unread'){
                                        echo "font-weight: bold; width: 200px";
                                      }
                                        ?>"

                                        class="dropdown-item" href="view.php?patient=<?php echo $qw['icPatient']; ?>"><i class="fa fa-fw fa-user"></i><?php echo $qw['registerDate']; ?><br/>
                                        <?php echo $qw['patientFirstName']; ?> <?php echo $qw['patientLastName']; ?>
                                        <p>new client</p>
                                        </a>
                                    </li>

                                    <?php
                                    }
                                  }
                                 ?>
                            </ul>
                            </li>
                            <li class="dropdown">
                              <?php
                              $queryy = mysqli_query($con,"SELECT a.*, b.*
                                                      FROM patient a
                                                      JOIN appointment b
                                                      On a.icPatient = b.patientIc WHERE b.status1 = 'unread'
                                                      Order By appId desc");
                                $arrayy = mysqli_fetch_all($queryy);

                                if (count($arrayy) > 0) {
                                ?>
                                   <a class="nav-link" id="dropdown01" data-toggle= "dropdown" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i style="font-size: 20px" class="fa fa-bell"></i>
                                     <span class="badge badge-light" style="background-color: red; font-size: 12px"><?php echo count($arrayy); ?></span>
                                   <?php
                                 }
                                  ?>
                                     </a>
                                   <ul class="dropdown-menu" style="margin-right: 40px">
                                       <?php
                                           if (count($arrayy) > 0) {
                                             foreach ($queryy as $qww) {
                                           ?>
                                                <li>
                                               <a style="
                                                      <?php if($qww['status1'] =='unread'){
                                               echo "font-weight: bold; width: 200px";
                                             }
                                               ?>"
                                                class="dropdown-item" href="view.php?patientId=<?php echo $qww['appId']; ?>"><br/>
                                                <i class="fa fa-fw fa-user"></i>
                                                 <?php echo $qww['patientFirstName']; ?> <?php echo $qww['patientLastName']; ?><br>
                                                <?php echo $qww['appDate']; ?><br>
                                               <?php echo $qww['startTime']; ?> <?php echo $qww['endTime']; ?>
                                               <h6>New appointment</h6>
                                               </a>
                                             </li>

                                           <?php
                                           }
                                         }
                                        ?>
                                   </ul>
                                   </li>

                <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i style="font-size: 20px" class="fa fa-user"></i> <?php echo $userRow['doctorFirstName']; ?> <?php echo $userRow['doctorMiddleName'];?>  <?php echo $userRow['doctorLastName']; ?> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="doctorprofile.php"><i  class="fa fa-fw fa-user"></i> Profile</a>
                            </li>
                            <li>
                                <a href="message.php"><i  class="fa fa-fw fa-user"></i> Message</a>
                            </li>

                            <li class="divider"></li>
                            <li>

                                <a href="logout.php?logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>
                </ul>

                <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav side-nav">
                      <li>
                         <a href="doctordashboard.php"><i class="fa fa-fw fa-dashboard"></i> Appointment Process</a>
                     </li>
                     <li>
                         <a href="addschedule.php"><i class="fa fa-fw fa-table"></i> Doctor List</a>
                     </li>
                     <li>
                         <a href="appointmentList.php"><i class="fa fa-fw fa-table"></i> Appointment List</a>
                     </li>
                     <li>
                         <a href="services.php"><i class="fa fa-fw fa-table"></i> Services</a>
                     </li>
                     <li>
                         <a href="updatepatient.php"><i class="fa fa-fw fa-table"></i> Patient List</a>
                     </li>
                     <li>
                         <a href="Monthly.php"><i class="fa fa-fw fa-table"></i> Monthly Income</a>
                     </li
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </nav>
            <!-- navigation end -->

            <div id="page-wrapper">
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">
                            Appointment List
                            </h2>
                        </div>
                    </div>
                    <!-- Page Heading end-->

                    <!-- panel start -->
                    <div class="panel panel-primary filterable">
                        <!-- Default panel contents -->
                       <div class="panel-heading">
                        <h3 class="panel-title">Appointment List</h3>
                        <div class="pull-right">
                            <button class="btn btn-default btn-xs btn-filter"><span class="fa fa-filter"></span> Filter</button>
                        </div>
                        </div>
                        <div class="panel-body">
                        <!-- Table -->
                        <div class="table-responsive">


                        <table id = "example" class="table table-bordered table-striped">
                            <thead>
                                <tr class="filters">
                                    <th><input type="text" class="form-control" placeholder="Name" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Email" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Subject" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="message" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Status" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Complete" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Delete" disabled></th>
                                </tr>
                            </thead>

                            <?php
                            $res=mysqli_query($con,"SELECT * FROM information Order By id desc");
                                  if (!$res) {
                                    printf("Error: %s\n", mysqli_error($con));
                                    exit();
                                }
                            while ($appoint=mysqli_fetch_array($res)) {

                                if ($appoint['status']=='unread') {
                                    $status="danger";
                                    $icon='remove';
                                    $checked='';

                                } else {
                                    $status="success";
                                    $icon='ok';
                                    $checked = 'disabled';
                                }

                                echo "<tbody>";
                                echo "<tr class='$status'>";
                                    echo "<td>" . $appoint['Name'] . "</td>";
                                    echo "<td>" . $appoint['Email'] . "</td>";
                                    echo "<td>" . $appoint['Subject'] . "</td>";
                                    echo "<td>" . $appoint['Message'] . "</td>";
                                    echo "<td><span class='glyphicon glyphicon-".$icon."' aria-hidden='true'></span>".' '."". $appoint['status'] . "</td>";
                                    echo "<form method='POST'>";
                                    echo "<td class='text-center'><input type='checkbox' name='enable' id='enable' value='".$appoint['id']."' onclick='chkit(".$appoint['id'].",this.checked);' ".$checked."></td>";
                                    echo "<td class='text-center'><a href='#' id='".$appoint['id']."' class='delete'><span class='glyphicon glyphicon-trash' aria-hidden='true'></span></a>
                            </td>";

                            }
                                echo "</tr>";
                           echo "</tbody>";
                       echo "</table>";
                         echo "<div class='panel panel-default'>";
                       echo "<div class='col-md-offset-3 pull-right'>";
                       echo "<button class='btn btn-primary' type='submit' value='Submit' name='submit'>Update</button>";
                        echo "</div>";
                        echo "</div>";
                        ?>
                    </div>
                </div>
              </div>

                    <!-- panel end -->
                    <script type="text/javascript">
function chkit(uid, chk) {
   chk = (chk==true ? "1" : "0");
   var url = "checkdb.php?userId="+uid+"&chkYesNo="+chk;
   if(window.XMLHttpRequest) {
      req = new XMLHttpRequest();
   } else if(window.ActiveXObject) {
      req = new ActiveXObject("Microsoft.XMLHTTP");
   }
   // Use get instead of post.
   req.open("GET", url, true);
   req.send(null);
}
</script>



                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
        </div>
        <!-- /#wrapper -->



        <!-- jQuery -->
        <script src="../patient/assets/js/jquery.js"></script>
        <script type="text/javascript">
$(function() {
$(".delete").click(function(){
var element = $(this);
var appid = element.attr("id");
var info = 'id=' + appid;
if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: "deleteappointment.php",
   data: info,
   success: function(){
 }
});
  $(this).parent().parent().fadeOut(300, function(){ $(this).remove();});
 }
return false;
});
});
</script>
        <!-- Bootstrap Core JavaScript -->
        <script src="../patient/assets/js/bootstrap.min.js"></script>
        <!-- Latest compiled and minified JavaScript -->
         <!-- script for jquery datatable start-->
        <script type="text/javascript">
            /*
            Please consider that the JS part isn't production ready at all, I just code it to show the concept of merging filters and titles together !
            */
            $(document).ready(function(){
                $('.filterable .btn-filter').click(function(){
                    var $panel = $(this).parents('.filterable'),
                    $filters = $panel.find('.filters input'),
                    $tbody = $panel.find('.table tbody');
                    if ($filters.prop('disabled') == true) {
                        $filters.prop('disabled', false);
                        $filters.first().focus();
                    } else {
                        $filters.val('').prop('disabled', true);
                        $tbody.find('.no-result').remove();
                        $tbody.find('tr').show();
                    }
                });

                $('.filterable .filters input').keyup(function(e){
                    /* Ignore tab key */
                    var code = e.keyCode || e.which;
                    if (code == '9') return;
                    /* Useful DOM data and selectors */
                    var $input = $(this),
                    inputContent = $input.val().toLowerCase(),
                    $panel = $input.parents('.filterable'),
                    column = $panel.find('.filters th').index($input.parents('th')),
                    $table = $panel.find('.table'),
                    $rows = $table.find('tbody tr');
                    /* Dirtiest filter function ever ;) */
                    var $filteredRows = $rows.filter(function(){
                        var value = $(this).find('td').eq(column).text().toLowerCase();
                        return value.indexOf(inputContent) === -1;
                    });
                    /* Clean previous no-result if exist */
                    $table.find('tbody .no-result').remove();
                    /* Show all rows, hide filtered ones (never do that outside of a demo ! xD) */
                    $rows.show();
                    $filteredRows.hide();
                    /* Prepend no-result row if all rows are filtered */
                    if ($filteredRows.length === $rows.length) {
                        $table.find('tbody').prepend($('<tr class="no-result text-center"><td colspan="'+ $table.find('.filters th').length +'">No result found</td></tr>'));
                    }
                });
            });
        </script>
        <!-- script for jquery datatable end-->

    </body>
</html>
