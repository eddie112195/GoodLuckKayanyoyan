<?php
session_start();
include_once '../assets/conn/dbconnect.php';
// include_once 'connection/server.php';
if(!isset($_SESSION['doctorSession']))
{
header("Location: ../index.php");
}
$usersession = $_SESSION['doctorSession'];
$res=mysqli_query($con,"SELECT * FROM admin WHERE username='$usersession'");
$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);



?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Monthly</title>
        <!-- Bootstrap Core CSS -->
        <!-- <link href="assets/css/bootstrap.css" rel="stylesheet"> -->
        <link href="assets/css/material.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="assets/css/sb-admin.css" rel="stylesheet">
        <link href="assets/css/time/bootstrap-clockpicker.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <script src="assets/js/jquery.min.js"></script>
 <link rel="stylesheet" type="text/css" href="assets/css/datatables.min.css"/>
 <link rel="stylesheet" type = "text/css" href="assets/css/buttons.datatables.min.css">


        <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
        <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

        <!--Font Awesome (added because you use icons in your prepend/append)-->
        <link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

        <!-- Inline CSS based on choices in "Settings" tab -->
        <style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>

        <!-- Custom Fonts -->
    </head>
    <body>
        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="doctordashboard.php">Welcome Admin <?php echo $userRow['doctorFirstName'];?></a>
                </div>
                <!-- Top Menu Items -->

                <ul class="nav navbar-right top-nav">
                     <li class="dropdown">
                       <?php
                         $query = mysqli_query($con, "SELECT * FROM patient WHERE status = 'unread' Order By patientId desc");
                         $array = mysqli_fetch_all($query);?>
                            <a class="nav-link" id="dropdown01" data-toggle= "dropdown" placeholder="User" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i style="font-size: 20px" class="fa fa-bell"></i>

                                <?php
                                  if (count($array) > 0) {
                                  ?>
                              <span class="badge badge-light" style="background-color: red; font-size: 12px"><?php echo count($array); ?></span>
                            <?php
                          }
                           ?>
                         </a>
                            <ul class="dropdown-menu" style="margin-right: 40px">
                                <?php
                                    if (count($array) > 0) {
                                      foreach ($query as $qw) {

                                    ?>
                                    <li  style="margin: 0px auto; padding: auto">
                                        <a style="
                                               <?php if($qw['status'] =='unread'){
                                        echo "font-weight: bold; width: 200px";
                                      }
                                        ?>"

                                        class="dropdown-item" href="view.php?patient=<?php echo $qw['icPatient']; ?>"><i class="fa fa-fw fa-user"></i><?php echo $qw['registerDate']; ?><br/>
                                        <?php echo $qw['patientFirstName']; ?> <?php echo $qw['patientLastName']; ?>
                                        <p>new client</p>
                                        </a>
                                    </li>

                                    <?php
                                    }
                                  }
                                 ?>
                            </ul>
                            </li>
                            <li class="dropdown">
                              <?php
                              $queryy = mysqli_query($con,"SELECT a.*, b.*
                                                      FROM patient a
                                                      JOIN appointment b
                                                      On a.icPatient = b.patientIc WHERE b.status1 = 'unread'
                                                      Order By appId desc");
                                $arrayy = mysqli_fetch_all($queryy);

                                if (count($arrayy) > 0) {
                                ?>
                                   <a class="nav-link" id="dropdown01" data-toggle= "dropdown" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i style="font-size: 20px" class="fa fa-bell"></i>
                                     <span class="badge badge-light" style="background-color: red; font-size: 12px"><?php echo count($arrayy); ?></span>
                                   <?php
                                 }
                                  ?>
                                     </a>
                                   <ul class="dropdown-menu" style="margin-right: 40px">
                                       <?php
                                           if (count($arrayy) > 0) {
                                             foreach ($queryy as $qww) {
                                           ?>
                                                <li>
                                               <a style="
                                                      <?php if($qww['status1'] =='unread'){
                                               echo "font-weight: bold; width: 200px";
                                             }
                                               ?>"
                                                class="dropdown-item" href="view.php?patientId=<?php echo $qww['appId']; ?>"><br/>
                                                <i class="fa fa-fw fa-user"></i>
                                                 <?php echo $qww['patientFirstName']; ?> <?php echo $qww['patientLastName']; ?><br>
                                                <?php echo $qww['appDate']; ?><br>
                                               <?php echo $qww['startTime']; ?> <?php echo $qww['endTime']; ?>
                                               <h6>New appointment</h6>
                                               </a>
                                             </li>

                                           <?php
                                           }
                                         }
                                        ?>
                                   </ul>
                                   </li>

                <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i style="font-size: 20px" class="fa fa-user"></i> <?php echo $userRow['doctorFirstName']; ?> <?php echo $userRow['doctorMiddleName'];?>  <?php echo $userRow['doctorLastName']; ?> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="doctorprofile.php"><i  class="fa fa-fw fa-user"></i> Profile</a>
                            </li>
                            <li>
                              <?php
                                $quer = mysqli_query($con, "SELECT * FROM information WHERE status = 'unread' Order By id desc");
                                $rows = mysqli_fetch_all($quer);
        ?>
                                <a href="inbox.php"><i class="fa fa-fw fa-envelope"></i> Inbox
                                  <?php

                                    if (count($rows) > 0) {
                                    ?>
                                <span class="badge badge-light" style="background-color: red; font-size: 10px"><?php echo count($rows); ?></span>
                              <?php
                            }
                             ?>

                                </a>
                            </li>

                            <li class="divider"></li>
                            <li>
                                <a href="logout.php?logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>

                </ul>

                <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav side-nav">
                      <li>
                         <a href="doctordashboard.php"><i class="fa fa-fw fa-dashboard"></i> Appointment Process</a>
                     </li>
                     <li>
                         <a href="addschedule.php"><i class="fa fa-fw fa-table"></i> Doctor List</a>
                     </li>
                     <li>
                         <a href="appointmentList.php"><i class="fa fa-fw fa-table"></i> Appointment List</a>
                     </li>
                     <li>
                         <a href="services.php"><i class="fa fa-fw fa-table"></i> Services</a>
                     </li>
                     <li>
                         <a href="updatepatient.php"><i class="fa fa-fw fa-table"></i> Patient List</a>
                     </li>
                     <li>
                         <a href="Monthly.php"><i class="fa fa-fw fa-table"></i> Monthly Income</a>
                     </li
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </nav>
            <!-- navigation end -->

            <div id="page-wrapper">
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">
                            Appointment List
                            </h2>
                            <ol class="breadcrumb">

                                <div class="container box">
                                  <h3 align="center"></h3>
                                  <br />

                                  <div class="table-responsive" style="width: 120%; margin-left: -110px">

                                    <table id="data" class="table table-bordered table-striped" >

                                      <thead>
                                        <tr>
                                          <th><input type="text" placeholder="patient Ic" style="width: 72px" disabled></th>
                                          <th><input type="text" placeholder="First name" style="width: 80px" disabled></th>
                                          <th><input type="text" placeholder="Last name" style="width: 80px" disabled></th>
                                          <th><input type="text" placeholder="Contact" style="width: 80px" disabled></th>
                                          <th><input type="text" placeholder="Date" style="width: 80px" disabled></th>
                                          <th><input type="text" placeholder="Start"style="width: 72px" disabled></th>
                                          <th><input type="text"  placeholder="End" style="width: 72px" disabled></th>
                                          <th><input type="text" placeholder="Service" disabled></th>
                                          <th><input type="text" placeholder="Price"style="width: 72px" disabled></th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                      <?php
                                      $res=mysqli_query($con,"SELECT a.*, b.*
                                                              FROM patient a
                                                              JOIN appointment b
                                                              On a.icPatient = b.patientIc
                                                              Order By appId desc");


                                      while ($appointment = $res->fetch_array()) {

                                              echo "<td>" . $appointment['patientIc'] . "</td>";
                                              echo "<td>" . $appointment['patientFirstName'] . "</td>";
                                              echo "<td>" . $appointment['patientLastName'] . "</td>";
                                              echo "<td>" . $appointment['patientPhone'] . "</td>";
                                              echo "<td>" . $appointment['appDate'] . "</td>";
                                              echo "<td>" . $appointment['startTime'] . "</td>";
                                              echo "<td>" . $appointment['endTime'] . "</td>";
                                              echo "<td>" . $appointment['appService'] . "</td>";
                                              echo "<td>" . $appointment['Price'] . "</td>";
                                              echo "</tr>";

                                      }
                                      echo "</tbody>";
                                        echo "</table>";


                                  ?>


                                  </div>
                                </div>
                                <br />
                                <br />
                            </ol>
                        </div>
                    </div>
                    <!-- Page Heading end-->

                    <!-- panel start -->

        <!-- script for jquery datatable end-->



                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
        </div>
        <!-- /#wrapper -->
            <script src="../patient/assets/js/jquery.js"></script>
                <script src="../patient/assets/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="assets/js/jquery-3.3.1.js"></script>
        <script type="text/javascript" src="assets/js/datatables.min.js"></script>
        <script type="text/javascript" src= "assets/js/datatable.js"></script>
        <script type="text/javascript" src= "assets/js/buttons.print.min.js"></script>
        <script type="text/javascript" src= "assets/js/jszip.min.js"></script>
        <script type="text/javascript" src= "assets/js/pdfmake.min.js"></script>
        <script type="text/javascript" src = "assets/js/buttons.html5.min.js"></script>


        <script>
        $(document).ready(function() {
    $('#data').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            {extend:'copy', className: 'btn btn-primary'},
            {extend:'pdf', className: 'btn btn-primary'},
             {extend:'print', className: 'btn btn-primary'}
        ]
    } );
} );
        </script>


        <!-- script for jquery datatable end-->

    </body>
</html>
