<?php
    include '../assets/conn/dbconnect.php';
    $appDate= "";
    $appService = "";
    $startTime = "";
    $endTime = "";
    $Price ="";
    if (isset($_GET['patient'])) {
      $icPatient = $_GET['patient'];
      $query = "UPDATE patient SET status = 'read' WHERE icPatient = $icPatient";
      mysqli_query($con,$query);
}

    elseif (isset($_GET['patientId'])) {
     $patientIc = $_GET['patientId'];
    $queryy = "UPDATE appointment SET status1 = 'read' WHERE appId = $patientIc";
    mysqli_query($con, $queryy);
  }

  if (isset($_POST['Message'])) {

      $patientIc = mysqli_real_escape_string($con, $_POST['Patient']);
      $staff = mysqli_real_escape_string($con, $_POST['staffs']);
      $message = mysqli_real_escape_string($con, $_POST['message']);
      $status = "unread";

      $query =  "INSERT INTO message ( PatientIc, staff, message, status, timeDate)
       VALUES ( '$patientIc','$staff', '$message', '$status', CURRENT_TIMESTAMP) ";
      $result = mysqli_query($con, $query);
      if( $result ){
 ?>
<script type="text/javascript">
 alert('Message Sent.');
</script>
<?php
}
  }
 ?>
 <?php

 session_start();
 include_once '../assets/conn/dbconnect.php';
 // include_once 'connection/server.php';
 if(!isset($_SESSION['doctorSession']))
 {
 header("Location: ../index.php");
 }
 $usersession = $_SESSION['doctorSession'];
 $res=mysqli_query($con,"SELECT * FROM admin WHERE Username='$usersession'");
 $userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);


 ?>
 <!DOCTYPE html>
 <html lang="en">
     <head>
         <meta charset="utf-8">
         <meta http-equiv="X-UA-Compatible" content="IE=edge">
         <meta name="viewport" content="width=device-width, initial-scale=1">
         <meta name="description" content="">
         <meta name="author" content="">
         <title>Admin</title>
         <!-- Bootstrap Core CSS -->
         <!-- <link href="assets/css/bootstrap.css" rel="stylesheet"> -->
         <link href="assets/css/material.css" rel="stylesheet">
         <!-- Custom CSS -->
         <link href="assets/css/sb-admin.css" rel="stylesheet">
         <link href="assets/css/time/bootstrap-clockpicker.css" rel="stylesheet">
         <link href="assets/css/style.css" rel="stylesheet">
         <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
         <script src="assets/js/jquery-3.3.1.js" type="text/javascript"></script>
         <link rel="stylesheet" type="text/css" href="assets/css/jquery.dataTables.min.css"/>
         <link rel="stylesheet" type="text/css" href="assets/css/buttons.dataTables.min.css"/>
         <script type="text/javascript" src="assets/js/dataTables.buttons.min.js"></script>
         <script src="assets/js/dataTables.buttons.min.js" type="text/javascript"></script>
         <script src="assets/js/buttons.flash.min.js" type="text/javascript"></script>
         <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
         <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

         <!--Font Awesome (added because you use icons in your prepend/append)-->
         <link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

         <!-- Inline CSS based on choices in "Settings" tab -->
         <style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>

         <!-- Custom Fonts -->
     </head>
     <body>
         <div id="wrapper">

             <!-- Navigation -->
             <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                 <!-- Brand and toggle get grouped for better mobile display -->
                 <div class="navbar-header">
                     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                     <span class="sr-only">Toggle navigation</span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     </button>
                     <a class="navbar-brand" href="doctordashboard.php">Welcome Admin <?php echo $userRow['doctorFirstName'];?></a>
                 </div>
                 <!-- Top Menu Items -->

                 <ul class="nav navbar-right top-nav">
                      <li class="dropdown">
                        <?php
                          $query = mysqli_query($con, "SELECT * FROM patient WHERE status = 'unread' Order By patientId desc");
                          $array = mysqli_fetch_all($query);?>
                             <a class="nav-link" id="dropdown01" data-toggle= "dropdown" placeholder="User" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i style="font-size: 20px" class="fa fa-bell"></i>

                                 <?php
                                   if (count($array) > 0) {
                                   ?>
                               <span class="badge badge-light" style="background-color: red; font-size: 12px"><?php echo count($array); ?></span>
                             <?php
                           }
                            ?>
                          </a>
                             <ul class="dropdown-menu" style="margin-right: 40px">
                                 <?php
                                     if (count($array) > 0) {
                                       foreach ($query as $qw) {

                                     ?>
                                     <li  style="margin: 0px auto; padding: auto">
                                         <a style="
                                                <?php if($qw['status'] =='unread'){
                                         echo "font-weight: bold; width: 200px";
                                       }
                                         ?>"

                                         class="dropdown-item" href="view.php?patient=<?php echo $qw['icPatient']; ?>"><i class="fa fa-fw fa-user"></i><?php echo $qw['registerDate']; ?><br/>
                                         <?php echo $qw['patientFirstName']; ?> <?php echo $qw['patientLastName']; ?>
                                         <p>new client</p>
                                         </a>
                                     </li>

                                     <?php
                                     }
                                   }
                                  ?>
                             </ul>
                             </li>
                             <li class="dropdown">
                               <?php
                               $queryy = mysqli_query($con,"SELECT a.*, b.*
                                                       FROM patient a
                                                       JOIN appointment b
                                                       On a.icPatient = b.patientIc WHERE b.status1 = 'unread'
                                                       Order By appId desc");
                                 $arrayy = mysqli_fetch_all($queryy);

                                 if (count($arrayy) > 0) {
                                 ?>
                                    <a class="nav-link" id="dropdown01" data-toggle= "dropdown" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i style="font-size: 20px" class="fa fa-bell"></i>
                                      <span class="badge badge-light" style="background-color: red; font-size: 12px"><?php echo count($arrayy); ?></span>
                                    <?php
                                  }
                                   ?>
                                      </a>
                                    <ul class="dropdown-menu" style="margin-right: 40px">
                                        <?php
                                            if (count($arrayy) > 0) {
                                              foreach ($queryy as $qww) {
                                            ?>
                                                 <li>
                                                <a style="
                                                       <?php if($qww['status1'] =='unread'){
                                                echo "font-weight: bold; width: 200px";
                                              }
                                                ?>"
                                                 class="dropdown-item" href="view.php?patientId=<?php echo $qww['appId']; ?>"><br/>
                                                 <i class="fa fa-fw fa-user"></i>
                                                  <?php echo $qww['patientFirstName']; ?> <?php echo $qww['patientLastName']; ?><br>
                                                 <?php echo $qww['appDate']; ?><br>
                                                <?php echo $qww['startTime']; ?> <?php echo $qww['endTime']; ?>
                                                <h6>New appointment</h6>
                                                </a>
                                              </li>

                                            <?php
                                            }
                                          }
                                         ?>
                                    </ul>
                                    </li>

                 <li class="dropdown">
                         <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i style="font-size: 20px" class="fa fa-user"></i> <?php echo $userRow['doctorFirstName']; ?> <?php echo $userRow['doctorMiddleName'];?>  <?php echo $userRow['doctorLastName']; ?> <b class="caret"></b></a>
                         <ul class="dropdown-menu">
                             <li>
                                 <a href="doctorprofile.php"><i  class="fa fa-fw fa-user"></i> Profile</a>
                             </li>
                             <li>
                               <?php
                                 $quer = mysqli_query($con, "SELECT * FROM information WHERE status = 'unread' Order By id desc");
                                 $rows = mysqli_fetch_all($quer);
         ?>
                                 <a href="inbox.php"><i class="fa fa-fw fa-envelope"></i> Inbox
                                   <?php

                                     if (count($rows) > 0) {
                                     ?>
                                 <span class="badge badge-light" style="background-color: red; font-size: 10px"><?php echo count($rows); ?></span>
                               <?php
                             }
                              ?>

                                 </a>
                             </li>
                             <li>
                                 <a href="message.php"><i  class="fa fa-fw fa-user"></i> Message</a>
                             </li>

                             <li class="divider"></li>
                             <li>
                                 <a href="logout.php?logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                             </li>
                         </ul>
                     </li>

                 </ul>

                 <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
                 <div class="collapse navbar-collapse navbar-ex1-collapse">
                     <ul class="nav navbar-nav side-nav">
                       <li>
                          <a href="doctordashboard.php"><i class="fa fa-fw fa-dashboard"></i> Appointment Process</a>
                      </li>
                      <li>
                          <a href="addschedule.php"><i class="fa fa-fw fa-table"></i> Doctor List</a>
                      </li>
                      <li>
                          <a href="appointmentList.php"><i class="fa fa-fw fa-table"></i> Appointment List</a>
                      </li>
                      <li>
                          <a href="services.php"><i class="fa fa-fw fa-table"></i> Services</a>
                      </li>
                      <li>
                          <a href="updatepatient.php"><i class="fa fa-fw fa-table"></i> Patient List</a>
                      </li>
                      <li>
                          <a href="Monthly.php"><i class="fa fa-fw fa-table"></i> Monthly Income</a>
                      </li
                     </ul>
                 </div>
                 <!-- /.navbar-collapse -->
             </nav>

             <!-- navigation end -->

             <div id="page-wrapper">
                 <div class="container-fluid">

                     <!-- Page Heading -->
                     <div class="row">
                         <div class="col-lg-12">
                             <h2 class="page-header">
                               Appointment
                             </h2>
                             <ol class="breadcrumb">
                                 <li class="active">
                                     <i class="fa fa-calendar"></i> Appointment List
                                 </li>
                             </ol>
                         </div>
                     </div>
                     <!-- Page Heading end-->

                     <!-- panel start -->
                     <div class="panel panel-primary">

                         <!-- panel heading starat -->
                         <div class="panel-heading">
                             <h3 class="panel-title">Appoint</h3>
                         </div>
                         <!-- panel heading end -->

                         <div class="panel-body">
                         <!-- panel content start -->
                           <div class="container">
             <section style="padding-bottom: 50px; padding-top: 50px;">
                 <div class="row">
                     <!-- start -->
                     <!-- USER PROFILE ROW STARTS-->
                     <div class="row">
                         <div class="col-md-3 col-sm-3">

                             <div class="user-wrapper">
                                 <img src="assets/img/1.jpg" class="img-responsive" />
                                 <div class="description">
                                     <h4><?php echo $userRow['doctorFirstName']; ?> <?php echo $userRow['doctorLastName']; ?></h4>
                                     <h5> <strong> Admin </strong></h5>

                                     <hr />
                                      </div>
                             </div>
                         </div>
                         <?php

                         if (isset($_GET['patientId'])) {
                          $patientIc = $_GET['patientId'];
                          $rec = mysqli_query($con, "SELECT *
                          		FROM patient a
                          		JOIN appointment b
                          		On a.icPatient = b.patientIc
                          		WHERE b.appId = '$patientIc'");
                          $record = mysqli_fetch_array($rec);
                          $appDate = $record['appDate'];
                          $PatientIc = $record['icPatient'];
                          $appService = $record['appService'];
                          $Price = $record['Price'];
                          $startTime =$record['startTime'];
                          $endTime =$record['endTime'];
                          $note = "Appointment Date :";
                          $note1 = "Time :";

                       }
                       if (isset($_GET['patient'])) {
                        $patientIc = $_GET['patient'];
                        $rec = mysqli_query($con, "SELECT *
                            FROM patient
                        WHERE icPatient = '$patientIc'");
                        $record = mysqli_fetch_array($rec);
                        $PatientIc = $record['icPatient'];
                        $appDate = $record['registerDate'];
                        $appService = $record['patientEmail'];
                        $Price = $record['patientDOB'];
                        $startTime = $record['patientGender'];
                        $note = "Patient Info";
                        $note1 = "Gender";
                     }
                          ?>

                         <div class="col-md-9 col-sm-9  user-wrapper">
                             <div class="description">
                                 <h5>Patient name :<h4><?php echo $record['patientFirstName']; ?> <?php echo $record['patientLastName']; ?> </h3>
                                 <hr />

                                 <div class="panel panel-default">
                                     <div class="panel-body">


                                       <form action="<?php $_PHP_SELF ?>" method="POST" class="form" role="form" style="width: 500px" >
                                           <h4></h4>
                                           <div class="row">
                                             <input type="text" name="Patient" value="<?php echo $PatientIc; ?>" class="form-control input-lg"/>

                                               <div class="col-xs-6 col-md-6">
                                                 <?php echo $note; ?>
                                                   <input type="text" name="" pattern = "[A-Za-z ]{1,20}" value="<?php echo $appDate; ?>" class="form-control input-lg" disabled>
                                               </div>
                                               <div class="col-xs-6 col-md-6">
                                                    <?php echo $note1; ?>
                                                   <input type="text" pattern = "[A-Za-z ]{1,20}" value="<?php echo $startTime; ?>  -  <?php echo $endTime; ?>" class="form-control input-lg" placeholder="Last Name" disabled/>
                                               </div>
                                           </div>

                                           <input type="email" name="patientEmail" value="<?php echo $appService; ?>" class="form-control input-lg" placeholder=""  disabled/>

                                           <input type="text" name="Username" value="<?php echo $Price; ?>" class="form-control input-lg"  disabled/>
                                           <input type="text" name="staffs" value="Admin" class="form-control input-lg">

                                           <textarea type="text" name="message" class="form-control" placeholder="Message"></textarea>
                                           <br>
                                           <button class="btn btn-lg btn-primary" type="submit" name="Message" id="signup" style="border-radius : 12px" style="color: blue">Message</button>
                                       </form>
                                     </div>
                                 </div>

                             </div>

                         </div>
                     </div>
                     <!-- USER PROFILE ROW END-->
                     <div class="col-md-4">

                         <!-- Large modal -->

                         <!-- Modal --

                     </div>
                         <!-- panel content end -->
                         <!-- panel end -->
                         </div>
                     </div>
                     <!-- panel start -->

                 </div>
             </div>
         <!-- /#wrapper -->



         <!-- jQuery -->
         <script src="../patient/assets/js/jquery.js"></script>

         <!-- Bootstrap Core JavaScript -->
         <script src="../patient/assets/js/bootstrap.min.js"></script>
         <script src="assets/js/bootstrap-clockpicker.js"></script>
         <!-- Latest compiled and minified JavaScript -->
          <!-- script for jquery datatable start-->
         <!-- Include Date Range Picker -->
     </body>
 </html>
