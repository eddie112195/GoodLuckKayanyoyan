<?php
session_start();

include_once 'server1.php';
$update = false;
$male="";
$female="";
$single="";
$married="";
$separated="";
$divorced="";
$widowed="";
if (isset($_GET['edit'])) {
  $update = true;
    $staffId = $_GET['edit'];

  $rec = mysqli_query($con, "SELECT * FROM staff WHERE id = $staffId");
  $record = mysqli_fetch_array($rec);
  $staffIc = $record['icNumber'];
  $Username = $record['staff'];
  $Password = $record['password'];
  $staffFirstName = $record['staffFirstName'];
  $staffLastName = $record['staffLastName'];
  $staffPhone = $record['staffPhone'];
    $Position = $record['Position'];
  $editstate = true;

}
if (isset($_POST['update1'])) {

        $staffIc = mysqli_real_escape_string($con, $_POST['staffIc']);
        $Username =mysqli_real_escape_string($con, $_POST['Username']);
        $Password =mysqli_real_escape_string($con, $_POST['Password']);
        $staffFirstName = mysqli_real_escape_string($con, $_POST['staffFirstName']);
            $staffLastName = mysqli_real_escape_string($con, $_POST['staffLastName']);
                $staffPhone = mysqli_real_escape_string($con, $_POST['staffPhone']);
                $Position =mysqli_real_escape_string($con, $_POST['Position']);
                    $staffId = mysqli_real_escape_string($con, $_POST['staffId']);

  mysqli_query($con, "UPDATE staff SET icNumber ='$staffIc', staff = '$Username', password = '$Password', staffFirstName='$staffFirstName', staffLastName='$staffLastName', doctorPhone = '$doctorPhone', Position ='$Position' WHERE id = $staffId ");

  $_SESSION['message'] = 'Updated profile';
  $_SESSION['msg_type'] = 'success';
  header("Location: addschedule.php");
}
// include_once 'connection/server.php';
if(!isset($_SESSION['doctorSession']))
{
header("Location: ../index.php");
}

$usersession = $_SESSION['doctorSession'];
$res=mysqli_query($con,"SELECT * FROM admin WHERE username='$usersession'");
$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Welcome Dr <?php echo $userRow['doctorFirstName'];?> <?php echo $userRow['doctorLastName'];?></title>
        <!-- Bootstrap Core CSS -->
        <!-- <link href="assets/css/bootstrap.css" rel="stylesheet"> -->
        <link href="assets/css/material.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="assets/css/sb-admin.css" rel="stylesheet">
        <link href="assets/css/time/bootstrap-clockpicker.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <script src="assets/js/jquery.min.js"></script>
 <link rel="stylesheet" type="text/css" href="assets/css/datatables.min.css"/>
 <link rel="stylesheet" type = "text/css" href="assets/css/buttons.datatables.min.css">

        <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
        <!-- Custom Fonts -->
    </head>
    <body>
        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="doctordashboard.php">Welcome Admin <?php echo $userRow['doctorFirstName'];?></a>
                </div>
                <!-- Top Menu Items -->

                <ul class="nav navbar-right top-nav">
                     <li class="dropdown">
                       <?php
                         $query = mysqli_query($con, "SELECT * FROM patient WHERE status = 'unread' Order By patientId desc");
                         $array = mysqli_fetch_all($query);?>
                            <a class="nav-link" id="dropdown01" data-toggle= "dropdown" placeholder="User" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i style="font-size: 20px" class="fa fa-bell"></i>

                                <?php
                                  if (count($array) > 0) {
                                  ?>
                              <span class="badge badge-light" style="background-color: red; font-size: 12px"><?php echo count($array); ?></span>
                            <?php
                          }
                           ?>
                         </a>
                            <ul class="dropdown-menu" style="margin-right: 40px">
                                <?php
                                    if (count($array) > 0) {
                                      foreach ($query as $qw) {

                                    ?>
                                    <li  style="margin: 0px auto; padding: auto">
                                        <a style="
                                               <?php if($qw['status'] =='unread'){
                                        echo "font-weight: bold; width: 200px";
                                      }
                                        ?>"

                                        class="dropdown-item" href="view.php?patient=<?php echo $qw['icPatient']; ?>"><i class="fa fa-fw fa-user"></i><?php echo $qw['registerDate']; ?><br/>
                                        <?php echo $qw['patientFirstName']; ?> <?php echo $qw['patientLastName']; ?>
                                        <p>new client</p>
                                        </a>
                                    </li>

                                    <?php
                                    }
                                  }
                                 ?>
                            </ul>
                            </li>
                            <li class="dropdown">
                              <?php
                              $queryy = mysqli_query($con,"SELECT a.*, b.*
                                                      FROM patient a
                                                      JOIN appointment b
                                                      On a.icPatient = b.patientIc WHERE b.status1 = 'unread'
                                                      Order By appId desc");
                                $arrayy = mysqli_fetch_all($queryy);

                                if (count($arrayy) > 0) {
                                ?>
                                   <a class="nav-link" id="dropdown01" data-toggle= "dropdown" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i style="font-size: 20px" class="fa fa-bell"></i>
                                     <span class="badge badge-light" style="background-color: red; font-size: 12px"><?php echo count($arrayy); ?></span>
                                   <?php
                                 }
                                  ?>
                                     </a>
                                   <ul class="dropdown-menu" style="margin-right: 40px">
                                       <?php
                                           if (count($arrayy) > 0) {
                                             foreach ($queryy as $qww) {
                                           ?>
                                                <li>
                                               <a style="
                                                      <?php if($qww['status1'] =='unread'){
                                               echo "font-weight: bold; width: 200px";
                                             }
                                               ?>"
                                                class="dropdown-item" href="view.php?patientId=<?php echo $qww['appId']; ?>"><br/>
                                                <i class="fa fa-fw fa-user"></i>
                                                 <?php echo $qww['patientFirstName']; ?> <?php echo $qww['patientLastName']; ?><br>
                                                <?php echo $qww['appDate']; ?><br>
                                               <?php echo $qww['startTime']; ?> <?php echo $qww['endTime']; ?>
                                               <h6>New appointment</h6>
                                               </a>
                                             </li>

                                           <?php
                                           }
                                         }
                                        ?>
                                   </ul>
                                   </li>

                <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i style="font-size: 20px" class="fa fa-user"></i> <?php echo $userRow['doctorFirstName']; ?> <?php echo $userRow['doctorMiddleName'];?>  <?php echo $userRow['doctorLastName']; ?> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="doctorprofile.php"><i  class="fa fa-fw fa-user"></i> Profile</a>
                            </li>
                            <li>
                              <?php
                                $quer = mysqli_query($con, "SELECT * FROM information WHERE status = 'unread' Order By id desc");
                                $rows = mysqli_fetch_all($quer);
        ?>
                                <a href="inbox.php"><i class="fa fa-fw fa-envelope"></i> Inbox
                                  <?php

                                    if (count($rows) > 0) {
                                    ?>
                                <span class="badge badge-light" style="background-color: red; font-size: 10px"><?php echo count($rows); ?></span>
                              <?php
                            }
                             ?>

                                </a>
                            </li>
                            <li>
                                <a href="message.php"><i  class="fa fa-fw fa-user"></i> Message</a>
                            </li>

                            <li class="divider"></li>
                            <li>
                                <a href="logout.php?logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>

                </ul>

                <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav side-nav">
                      <li>
                         <a href="doctordashboard.php"><i class="fa fa-fw fa-dashboard"></i> Appointment Process</a>
                     </li>
                     <li>
                         <a href="addschedule.php"><i class="fa fa-fw fa-table"></i> Doctor List</a>
                     </li>
                     <li>
                         <a href="appointmentList.php"><i class="fa fa-fw fa-table"></i> Appointment List</a>
                     </li>
                     <li>
                         <a href="services.php"><i class="fa fa-fw fa-table"></i> Services</a>
                     </li>
                     <li>
                         <a href="updatepatient.php"><i class="fa fa-fw fa-table"></i> Patient List</a>
                     </li>
                     <li>
                         <a href="Monthly.php"><i class="fa fa-fw fa-table"></i> Monthly Income</a>
                     </li
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </nav>         <!-- navigation end -->

            <div id="page-wrapper">
                <div class="container-fluid">

                    <!-- Page Heading -->
                        <div class="col-lg-12">
                            <h2 class="page-header">
                            Doctors
                            </h2>
                        </div>
                    <!-- Page Heading end-->

                    <!-- panel start -->
                    <?php if (isset($_SESSION ['message'])):

                     ?>
                     <div class="alert alert-<?=$_SESSION['msg_type']?>">
                       <?php
                            echo $_SESSION['message'];
                            unset($_SESSION['message']);
                          ?>
                        </div>
                      <?php endif ?>
                    <div class="panel panel-primary filterable">
                      <table class="table table-hover table-bordered">
                        <form method="post" action="addschedule.php">

                          <?php if($update == true): ?>

                            <input type="hidden" name="staffId" value="<?php echo $staffId; ?>">
                            <th><input type="text" class="form-control" name="staffIc"placeholder="Doctor Ic" value="<?php echo $staffIc; ?>"></th>
                              <th><input type="text" class="form-control" name="Position" placeholder="Position" value="<?php echo $Position; ?>"></th>
                            <th><input type="text" class="form-control" name="Username"placeholder="Username" value="<?php echo $Username; ?>"></th>
                            <th><input type="text" class="form-control" name="Password" placeholder="Password" value="<?php echo $Password; ?>"></th>
                            <th><input type="text" class="form-control" name="staffFirstName"placeholder="First name" value="<?php echo $staffFirstName; ?>"></th>
                            <th><input type="text" class="form-control" name="staffLastName" placeholder=" Last name" value="<?php echo $staffLastName; ?>"></th>
                            <th><input type="text" class="form-control" name="staffPhone" placeholder="ContactNo." value="<?php echo $staffPhone; ?>"></th>
                            <!-- <th><input type="text" class="form-control" placeholder="Email" disabled></th> -->

                          <h5><th><button type="submit" name="update1" class="btn btn-success" style="border-radius: 20px">Update</button></th>
                        <?php else: ?>
                          <input type="hidden" name="staffId">
                          <th><input type="text" class="form-control" name="staffIc"placeholder="Doctor Ic"></th>
                          <th><select name="Position" class = "form-control input-lg" style="margin-right: 20px" required>
                              <option value="">Position</option>
                              <option value="staff">staff</option>
                              <option value="doctor">Doctor</option>
                          </select></th>
                          <th><input type="text" class="form-control" name="Username"placeholder="Username" required></th>
                          <th><input type="text" class="form-control" name="Password"placeholder="Password" required></th>
                          <th><input type="text" class="form-control" name="staffFirstName"placeholder="First name" required></th>
                          <th><input type="text" class="form-control" name="staffLastName" placeholder=" Last name" required></th>
                          <th><input type="text" class="form-control" name="staffPhone" placeholder="ContactNo." required></th>
                          <!-- <th><input type="text" class="form-control" placeholder="Email" disabled></th> -->

                          <h5><th><button type="submit" name="update" class="btn btn-success" style="border-radius: 20px">Add</button></th>
                        <?php endif;  ?>
                      </form>
                    </table>
                        <!-- panel heading starat -->
                        <div class="panel-heading">
                            <h3 class="panel-title">List of Patients</h3>
                            <div class="pull-right">
                            <button class="btn btn-default btn-xs btn-filter"><span class="fa fa-filter"></span> Filter</button>
                        </div>
                        </div>
                        <!-- panel heading end -->

                        <div class="panel-body">
                        <!-- panel content start -->
                           <!-- Table -->
                        <table  id ="example" class="table table-hover table-bordered">
                            <thead>
                                <tr class="filters">
                                    <th><input type="text" class="form-control" placeholder="Doctor Ic" disabled></th>
                                      <th><input type="text" class="form-control" placeholder="Position" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Username" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Password" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="First name" disabled></th>
                                    <th><input type="text" class="form-control" placeholder=" Last name" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="ContactNo." disabled></th>
                                    <!-- <th><input type="text" class="form-control" placeholder="Email" disabled></th> -->

                                    <th colspan="2">Edit<span style="margin-left: 4em">Delete</th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php
                            $result=mysqli_query($con,"SELECT * FROM staff ORDER by id DESC");
                            while ($doctorRow=mysqli_fetch_array($result)){

                              echo "<tr>";

?>
                                <td> <?php echo $doctorRow['icNumber'];  ?></td>
                                <td> <?php echo $doctorRow['Position'];  ?></td>
                                <td> <?php echo $doctorRow['staff'];  ?></td>
                                <td> <?php echo $doctorRow['password'];  ?></td>
                              <td> <?php echo $doctorRow['staffFirstName'];  ?></td>
                            <td> <?php echo $doctorRow['staffLastName'];  ?></td>
                              <td> <?php echo $doctorRow['staffPhone'];  ?></td>

                              <form method='POST'>
                                <td>
                                  <a href="addschedule.php?edit=<?php echo $doctorRow['id']; ?>" class="btn btn-info" style="border-radius: 50%!important">*</a>
                              </td>
                              <?php echo "<td class='text-center'><a href='#' id='".$doctorRow['id']."' class='delete'><span class='btn btn-danger' aria-hidden='true' style = 'border-radius: 50%!important'>*</span></a>
                              </td>";
                              ?>
                            </tr>
</div>
</div>
<?php
          }
          echo "</tbody>";
          echo "</table>";

?>

    <!-- jQuery -->
          <script src="../patient/assets/js/jquery.js"></script>
        <script type="text/javascript">
$(function() {
$(".delete").click(function(){
var element = $(this);
var ic = element.attr("id");
var info = 'ic=' + ic;
if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: "deleteschedule.php",
   data: info,
   success: function(){
 }
});
  $(this).parent().parent().fadeOut(300, function(){ $(this).remove();});
 }
return false;
});
});
</script>
 <script type="text/javascript">
            /*
            Please consider that the JS part isn't production ready at all, I just code it to show the concept of merging filters and titles together !
            */
            $(document).ready(function(){
                $('.filterable .btn-filter').click(function(){
                    var $panel = $(this).parents('.filterable'),
                    $filters = $panel.find('.filters input'),
                    $tbody = $panel.find('.table tbody');
                    if ($filters.prop('disabled') == true) {
                        $filters.prop('disabled', false);
                        $filters.first().focus();
                    } else {
                        $filters.val('').prop('disabled', true);
                        $tbody.find('.no-result').remove();
                        $tbody.find('tr').show();
                    }
                });

                $('.filterable .filters input').keyup(function(e){
                    /* Ignore tab key */
                    var code = e.keyCode || e.which;
                    if (code == '9') return;
                    /* Useful DOM data and selectors */
                    var $input = $(this),
                    inputContent = $input.val().toLowerCase(),
                    $panel = $input.parents('.filterable'),
                    column = $panel.find('.filters th').index($input.parents('th')),
                    $table = $panel.find('.table'),
                    $rows = $table.find('tbody tr');
                    /* Dirtiest filter function ever ;) */
                    var $filteredRows = $rows.filter(function(){
                        var value = $(this).find('td').eq(column).text().toLowerCase();
                        return value.indexOf(inputContent) === -1;
                    });
                    /* Clean previous no-result if exist */
                    $table.find('tbody .no-result').remove();
                    /* Show all rows, hide filtered ones (never do that outside of a demo ! xD) */
                    $rows.show();
                    $filteredRows.hide();
                    /* Prepend no-result row if all rows are filtered */
                    if ($filteredRows.length === $rows.length) {
                        $table.find('tbody').prepend($('<tr class="no-result text-center"><td colspan="'+ $table.find('.filters th').length +'">No result found</td></tr>'));
                    }
                });
            });
        </script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../patient/assets/js/bootstrap.min.js"></script>
        <script src="assets/js/bootstrap-clockpicker.js"></script>
        <script type="text/javascript" src="assets/js/jquery-3.3.1.js"></script>
        <script type="text/javascript" src="assets/js/datatables.min.js"></script>
        <script type="text/javascript" src= "assets/js/datatable.js"></script>
        <script type="text/javascript" src= "assets/js/buttons.print.min.js"></script>

        <script>
        $(document).ready(function() {
    $('#example').DataTable( {

    } );
} );
        </script>

        <!-- Latest compiled and minified JavaScript -->
         <!-- script for jquery datatable start-->
        <!-- Include Date Range Picker -->
    </body>
</html>
