
 <?php
$icPatient = "";
$Username = "";
$patientFirstName = "";
 $patientLastName = "";
$patientEmail = "";
$icPatient = "";
$Username = "";
$password = "";
$patientPhone = "";
$patientDOB = "";
$patientGender = "";
$patientMaritialStatus = "";
$patientAddress = "";
$patientId = 0;
include_once '../assets/conn/dbconnect.php';

        if (isset($_POST['update'])) {

          $icPatient = mysqli_real_escape_string($con,$_POST['icPatient']);
          $Username = mysqli_real_escape_string($con,$_POST['Username']);
          $patientFirstName = mysqli_real_escape_string($con,$_POST['patientFirstName']);
          $patientLastName  = mysqli_real_escape_string($con,$_POST['patientLastName']);
          $patientEmail     = mysqli_real_escape_string($con,$_POST['patientEmail']);
          $icPatient     = mysqli_real_escape_string($con,$_POST['icPatient']);
          $patientPhone     = mysqli_real_escape_string($con,$_POST['patientPhone']);
          $password         = mysqli_real_escape_string($con,$_POST['password']);
          $patientDOB            = mysqli_real_escape_string($con,$_POST['patientDOB']);
          $patientGender = mysqli_real_escape_string($con,$_POST['patientGender']);
          $patientMaritialStatus = mysqli_real_escape_string($con,$_POST['patientMaritialStatus']);
          $patientAddress = mysqli_real_escape_string($con,$_POST['patientAddress']);
          $patientId = mysqli_real_escape_string($con,$_POST['patientId']);



          mysqli_query($con, "UPDATE patient SET icPatient = '$icPatient', Username = '$Username', patientFirstName='$patientFirstName', patientLastName='$patientLastName',password = '$password', patientAddress='$patientAddress', patientGender = '$patientGender', patientMaritialStatus = '$patientMaritialStatus', patientDOB = '$patientDOB', patientPhone = '$patientPhone', patientEmail='$patientEmail' WHERE patientId = $patientId");
          $_SESSION['message'] = 'Updated profile';
          $_SESSION['msg_type'] = 'success';
          header("Location: updatepatient.php");
        }
          ?>
