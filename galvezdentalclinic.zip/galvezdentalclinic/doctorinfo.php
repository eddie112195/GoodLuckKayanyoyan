<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content"style="border-radius : 17px; width: 576px">
                    <!-- modal content -->
                    <div class="modal-header">
                      <h3 class="modal-title" style="text-align: center"><span style="font-style: Bold">DOCTOR PROFILE</h3>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

                    </div>
                    <!-- modal body start -->
                    <div class="modal-body">

                        <!-- form start -->
                        <div class="container" id="wrap">
                            <div class="row">
                                <div class="col-md-6">

                                    <form action="<?php $_PHP_SELF ?>" method="POST" accept-charset="utf-8" class="form" role="form" style="width: 500px">
                                      <div class="col-lg-12 col-sm-7 text-center mb-4">
                                          <img class="rounded-circle img-fluid d-block mx-auto" src="assets/images/person_5.PNG" alt="" style="border-radius: 50%!important; height:200px; width:200px">
                                        </div>
                                          <div class="col-md-12 col-sm-12 col-xs-12 pad25">

                                            <h4>Doctor name : Maria Mercedes M. Galvez<br>
                                              <small>Holder degree: Dentistry</small><br>
                                              <small>DMD: Doctor of Dental Medicine</small><br>
                                              <small>29 years experience</small>
                                            </h4>
                                            <h5>Graduated: <h6> Centro Escolar University</h6>
                                            <h5>Address: <h6>Avida settings Molino IV Bacoor City</h6>
                                              <h5>Birthday: <h6>June 21, 1964</h6>
                                                <h5>Contact no: <h6>(046)-484 3217</h6><h6>09228676364</h6></h5>
                                          </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
