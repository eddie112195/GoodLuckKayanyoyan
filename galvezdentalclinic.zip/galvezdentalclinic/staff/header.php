<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<?php if ($userRow['Position'] == 'doctor') {
					$admin = "Doctor";
				}else {
					$admin ="Staff";
				}

				echo "<a class='navbar-brand' href='staffdashboard.php'>Welcome ".$admin." ".$userRow['staffFirstName']."</a>"
				?>
		</div>
		<!-- Top Menu Items -->

		<ul class="nav navbar-right top-nav">
				 <li class="dropdown">
					 <?php
						 $query = mysqli_query($con, "SELECT * FROM patient WHERE status = 'unread' Order By patientId desc");
						 $array = mysqli_fetch_all($query);
						 ?>
								<a class="nav-link" id="dropdown01" data-toggle= "dropdown" placeholder="User" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i style="font-size: 20px" class="fa fa-bell"></i>

										<?php
											if (count($array) > 0) {
											?>
									<span class="badge badge-light" style="background-color: red; font-size: 12px"><?php echo count($array); ?></span>
								<?php
							}
							 ?>
						 </a>
								<ul class="dropdown-menu" style="margin-right: 40px">
										<?php
												if (count($array) > 0) {
													foreach ($query as $qw) {

												?>
												<li  style="margin: 0px auto; padding: auto">
														<a style="
																	 <?php if($qw['status'] =='unread'){
														echo "font-weight: bold; width: 200px";
													}
														?>"

														class="dropdown-item" href="view.php?patient=<?php echo $qw['icPatient']; ?>"><i class="fa fa-fw fa-user"></i><?php echo $qw['registerDate']; ?><br/>
														<?php echo $qw['patientFirstName']; ?> <?php echo $qw['patientLastName']; ?>
														<p>new client</p>
														</a>
												</li>

												<?php
												}
											}
										 ?>
								</ul>
								</li>
								<li class="dropdown">
									<?php
									$queryy = mysqli_query($con,"SELECT a.*, b.*
																					FROM patient a
																					JOIN appointment b
																					On a.icPatient = b.patientIc WHERE b.status1 = 'unread'
																					Order By appId desc");
										$arrayy = mysqli_fetch_all($queryy);

										if (count($arrayy) > 0) {
										?>
											 <a class="nav-link" id="dropdown01" data-toggle= "dropdown" aria-haspopup= "true" aria-expanded ="false" style="border-radius: 50%!important"><i style="font-size: 20px" class="fa fa-bell"></i>
												 <span class="badge badge-light" style="background-color: red; font-size: 12px"><?php echo count($arrayy); ?></span>
											 <?php
										 }
											?>
												 </a>
											 <ul class="dropdown-menu" style="margin-right: 40px">
													 <?php
															 if (count($arrayy) > 0) {
																 foreach ($queryy as $qww) {
															 ?>
																		<li>
																	 <a style="
																					<?php if($qww['status1'] =='unread'){
																	 echo "font-weight: bold; width: 200px";
																 }
																	 ?>"
																		class="dropdown-item" href="view.php?patientId=<?php echo $qww['appId']; ?>"><br/>
																		<i class="fa fa-fw fa-user"></i>
																		 <?php echo $qww['patientFirstName']; ?> <?php echo $qww['patientLastName']; ?><br>
																		<?php echo $qww['appDate']; ?><br>
																	 <?php echo $qww['startTime']; ?> <?php echo $qww['endTime']; ?>
																	 <h6>New appointment</h6>
																	 </a>
																 </li>

															 <?php
															 }
														 }
														?>
											 </ul>
											 </li>

		<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i style="font-size: 20px" class="fa fa-user"></i> <?php echo $userRow['staffFirstName']; ?> <?php echo $userRow['staffLastName']; ?> <b class="caret"></b></a>
						<ul class="dropdown-menu">
								<li>
										<a href="staffprofile.php"><i  class="fa fa-fw fa-user"></i> Profile</a>
								</li>
								<li>
									<?php
										$quer = mysqli_query($con, "SELECT * FROM information WHERE status = 'unread' Order By id desc");
										$rows = mysqli_fetch_all($quer);
?>
										<a href="inbox.php"><i class="fa fa-fw fa-envelope"></i> Inbox
											<?php

												if (count($rows) > 0) {
												?>
										<span class="badge badge-light" style="background-color: red; font-size: 10px"><?php echo count($rows); ?></span>
									<?php
								}
								 ?>

										</a>
										<li>
												<a href="message.php"><i  class="fa fa-fw fa-user"></i> Message</a>
										</li>
								</li>

								<li class="divider"></li>
								<li>
										<a href="logout.php?logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
								</li>
						</ul>
				</li>

		</ul>

		<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
		<div class="collapse navbar-collapse navbar-ex1-collapse">
				<ul class="nav navbar-nav side-nav">
					<li>
						 <a href="staffdashboard.php"><i class="fa fa-fw fa-dashboard"></i> Appointment Process</a>
				 </li>

				 <li>
						 <a href="appointmentList.php"><i class="fa fa-fw fa-table"></i> Appointment List</a>
				 </li>
				 <li>
						 <a href="services.php"><i class="fa fa-fw fa-table"></i> Services</a>
				 </li>
				 <li>
						 <a href="updatepatient.php"><i class="fa fa-fw fa-table"></i> Patient List</a>
				 </li>
				 <li>
						 <a href="Monthly.php"><i class="fa fa-fw fa-table"></i> Monthly Income</a>
				 </li
				</ul>
		</div>
		<!-- /.navbar-collapse -->
</nav>
