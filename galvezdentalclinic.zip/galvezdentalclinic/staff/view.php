<?php
    include '../assets/conn/dbconnect.php';
    $appDate= "";
    $appService = "";
    $startTime = "";
    $endTime = "";
    $Price ="";
    if (isset($_GET['patient'])) {
      $icPatient = $_GET['patient'];
      $query = "UPDATE patient SET status = 'read' WHERE icPatient = $icPatient";
      mysqli_query($con,$query);
}

    elseif (isset($_GET['patientId'])) {
     $patientIc = $_GET['patientId'];
    $queryy = "UPDATE appointment SET status1 = 'read' WHERE appId = $patientIc";
    mysqli_query($con, $queryy);
  }

  if (isset($_POST['Message'])) {

      $patientIc = mysqli_real_escape_string($con, $_POST['Patient']);
      $staff = mysqli_real_escape_string($con, $_POST['staffs']);
      $message = mysqli_real_escape_string($con, $_POST['message']);
      $status = "unread";

      $query =  "INSERT INTO message ( PatientIc, staff, message, status, timeDate)
       VALUES ( '$patientIc','$staff', '$message', '$status', CURRENT_TIMESTAMP) ";
      $result = mysqli_query($con, $query);
      if( $result ){
 ?>
<script type="text/javascript">
 alert('Message Sent.');
</script>
<?php
}
  }
 ?>
 <?php

 session_start();
 include_once '../assets/conn/dbconnect.php';
 // include_once 'connection/server.php';
 if(!isset($_SESSION['employeeSession']))
 {
 header("Location: ../index.php");
 }
 $usersession = $_SESSION['employeeSession'];
 $res=mysqli_query($con,"SELECT * FROM staff WHERE staff='$usersession'");
 $userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);


 ?>
 <!DOCTYPE html>
 <html lang="en">
     <head>
         <meta charset="utf-8">
         <meta http-equiv="X-UA-Compatible" content="IE=edge">
         <meta name="viewport" content="width=device-width, initial-scale=1">
         <meta name="description" content="">
         <meta name="author" content="">
         <?php if ($userRow['Position'] == 'doctor') {
           $admin = "Doctor";
         }else {
           $admin ="Staff";
         }

         echo "<title>Welcome ".$admin." ".$userRow['staffFirstName']."</title>"
         ?>
         <!-- Bootstrap Core CSS -->
         <!-- <link href="assets/css/bootstrap.css" rel="stylesheet"> -->
         <link href="assets/css/material.css" rel="stylesheet">
         <!-- Custom CSS -->
         <link href="assets/css/sb-admin.css" rel="stylesheet">
         <link href="assets/css/time/bootstrap-clockpicker.css" rel="stylesheet">
         <link href="assets/css/style.css" rel="stylesheet">
         <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
         <script src="assets/js/jquery-3.3.1.js" type="text/javascript"></script>
         <link rel="stylesheet" type="text/css" href="assets/css/jquery.dataTables.min.css"/>
         <link rel="stylesheet" type="text/css" href="assets/css/buttons.dataTables.min.css"/>
         <script type="text/javascript" src="assets/js/dataTables.buttons.min.js"></script>
         <script src="assets/js/dataTables.buttons.min.js" type="text/javascript"></script>
         <script src="assets/js/buttons.flash.min.js" type="text/javascript"></script>
         <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
         <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

         <!--Font Awesome (added because you use icons in your prepend/append)-->
         <link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

         <!-- Inline CSS based on choices in "Settings" tab -->
         <style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>

         <!-- Custom Fonts -->
     </head>
     <body>
         <div id="wrapper">

             <!-- Navigation -->
             <?php include 'header.php'; ?>
             <!-- navigation end -->

             <div id="page-wrapper">
                 <div class="container-fluid">

                     <!-- Page Heading -->
                     <div class="row">
                         <div class="col-lg-12">
                             <h2 class="page-header">
                               Appointment
                             </h2>
                             <ol class="breadcrumb">
                                 <li class="active">
                                     <i class="fa fa-calendar"></i> Appointment List
                                 </li>
                             </ol>
                         </div>
                     </div>
                     <!-- Page Heading end-->

                     <!-- panel start -->
                     <div class="panel panel-primary">

                         <!-- panel heading starat -->
                         <div class="panel-heading">
                             <h3 class="panel-title">Appoint</h3>
                         </div>
                         <!-- panel heading end -->

                         <div class="panel-body">
                         <!-- panel content start -->
                           <div class="container">
             <section style="padding-bottom: 50px; padding-top: 50px;">
                 <div class="row">
                     <!-- start -->
                     <!-- USER PROFILE ROW STARTS-->
                     <div class="row">
                         <div class="col-md-3 col-sm-3">

                             <div class="user-wrapper">
                                 <img src="assets/img/1.jpg" class="img-responsive" />
                                 <div class="description">
                                     <h4><?php echo $userRow['staffFirstName']; ?> <?php echo $userRow['staffLastName']; ?></h4>
                                     <h5> <strong> Doctor </strong></h5>

                                     <hr />
                                      </div>
                             </div>
                         </div>
                         <?php

                         if (isset($_GET['patientId'])) {
                          $patientIc = $_GET['patientId'];
                          $rec = mysqli_query($con, "SELECT *
                          		FROM patient a
                          		JOIN appointment b
                          		On a.icPatient = b.patientIc
                          		WHERE b.appId = '$patientIc'");
                          $record = mysqli_fetch_array($rec);
                          $appDate = $record['appDate'];
                          $PatientIc = $record['icPatient'];
                          $appService = $record['appService'];
                          $Price = $record['Price'];
                          $startTime =$record['startTime'];
                          $endTime =$record['endTime'];
                          $note = "Appointment Date :";
                          $note1 = "Time :";

                       }
                       if (isset($_GET['patient'])) {
                        $patientIc = $_GET['patient'];
                        $rec = mysqli_query($con, "SELECT *
                            FROM patient
                        WHERE icPatient = '$patientIc'");
                        $record = mysqli_fetch_array($rec);
                        $PatientIc = $record['icPatient'];
                        $appDate = $record['registerDate'];
                        $appService = $record['patientEmail'];
                        $Price = $record['patientDOB'];
                        $startTime = $record['patientGender'];
                        $note = "Patient Info";
                        $note1 = "Gender";
                     }
                          ?>

                         <div class="col-md-9 col-sm-9  user-wrapper">
                             <div class="description">
                                 <h5>Patient name :<h4><?php echo $record['patientFirstName']; ?> <?php echo $record['patientLastName']; ?> </h3>
                                 <hr />

                                 <div class="panel panel-default">
                                     <div class="panel-body">


                                       <form action="<?php $_PHP_SELF ?>" method="POST" class="form" role="form" style="width: 500px" >
                                           <h4></h4>
                                           <div class="row">
                                             <input type="text" name="Patient" value="<?php echo $PatientIc; ?>" class="form-control input-lg"/>

                                               <div class="col-xs-6 col-md-6">
                                                 <?php echo $note; ?>
                                                   <input type="text" name="" pattern = "[A-Za-z ]{1,20}" value="<?php echo $appDate; ?>" class="form-control input-lg" disabled>
                                               </div>
                                               <div class="col-xs-6 col-md-6">
                                                    <?php echo $note1; ?>
                                                   <input type="text" pattern = "[A-Za-z ]{1,20}" value="<?php echo $startTime; ?>  -  <?php echo $endTime; ?>" class="form-control input-lg" placeholder="Last Name" disabled/>
                                               </div>
                                           </div>

                                           <input type="email" name="patientEmail" value="<?php echo $appService; ?>" class="form-control input-lg" placeholder=""  disabled/>

                                           <input type="text" name="Username" value="<?php echo $Price; ?>" class="form-control input-lg"  disabled/>
                                           <input type="text" name="staffs" value="<?php echo $userRow['Position']; ?>" class="form-control input-lg">

                                           <textarea type="text" name="message" class="form-control" placeholder="Message"></textarea>
                                           <br>
                                           <button class="btn btn-lg btn-primary" type="submit" name="Message" id="signup" style="border-radius : 12px" style="color: blue">Message</button>
                                       </form>
                                     </div>
                                 </div>

                             </div>

                         </div>
                     </div>
                     <!-- USER PROFILE ROW END-->
                     <div class="col-md-4">

                         <!-- Large modal -->

                         <!-- Modal --

                     </div>
                         <!-- panel content end -->
                         <!-- panel end -->
                         </div>
                     </div>
                     <!-- panel start -->

                 </div>
             </div>
         <!-- /#wrapper -->



         <!-- jQuery -->
         <script src="../patient/assets/js/jquery.js"></script>

         <!-- Bootstrap Core JavaScript -->
         <script src="../patient/assets/js/bootstrap.min.js"></script>
         <script src="assets/js/bootstrap-clockpicker.js"></script>
         <!-- Latest compiled and minified JavaScript -->
          <!-- script for jquery datatable start-->
         <!-- Include Date Range Picker -->
     </body>
 </html>
