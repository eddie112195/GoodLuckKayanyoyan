 include '../assets/conn/dbconnect.php';

 <?php
$timeId = 0;
$timeschedule = "";

if (isset($_POST['update1'])){

$timeId = mysqli_real_escape_string($con,$_POST['timeId']);
$timeschedule = mysqli_real_escape_string($con,$_POST['TimeSchedule']);

    mysqli_query($con, "UPDATE timeschedule SET TimeSchedule = '$timeschedule' WHERE timeId = $timeId");
    $_SESSION['message'] = 'Updated Time';
    $_SESSION['msg_type'] = 'success';
    header("Location: services.php");
}
 ?>

 <?php
      include '../assets/conn/dbconnect.php';

      $servicesId = 0;
      $services = "";
      $price = "";

          if (isset($_POST['updated'])){


            $servicesId = mysqli_real_escape_string($con, $_POST['servicesId']);
            $services = mysqli_real_escape_string($con, $_POST['Services']);
            $price = mysqli_real_escape_string($con, $_POST['price']);

            mysqli_query($con, "UPDATE services SET Services = '$services', Price = '$price' WHERE servicesId = $servicesId");

            $_SESSION['message'] = 'Updated services';
            $_SESSION['msg_type'] = 'success';
            header("Location: services.php");
          }


  ?>
