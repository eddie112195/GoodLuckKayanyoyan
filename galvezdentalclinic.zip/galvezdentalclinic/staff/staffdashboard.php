<?php
session_start();
include_once '../assets/conn/dbconnect.php';
// include_once 'connection/server.php';
if(!isset($_SESSION['employeeSession']))
{
header("Location: ../index.php");
}
$usersession = $_SESSION['employeeSession'];
$res=mysqli_query($con,"SELECT * FROM staff WHERE staff='$usersession'");
$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);



?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <?php if ($userRow['Position'] == 'doctor') {
          $admin = "Doctor";
        }else {
          $admin ="Staff";
        }

        echo "<title>Welcome ".$admin." ".$userRow['staffFirstName']."</title>"
        ?>
        <!-- Bootstrap Core CSS -->
        <!-- <link href="assets/css/bootstrap.css" rel="stylesheet"> -->
        <link href="assets/css/material.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="assets/css/sb-admin.css" rel="stylesheet">
        <link href="assets/css/time/bootstrap-clockpicker.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="assets/css/datatables.min.css"/>
        <link rel="stylesheet" type = "text/css" href="assets/css/buttons.datatables.min.css">

        <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
        <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

        <!--Font Awesome (added because you use icons in your prepend/append)-->
        <link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

        <!-- Inline CSS based on choices in "Settings" tab -->
        <style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>

        <!-- Custom Fonts -->
    </head>
    <body>
        <div id="wrapper">

            <!-- Navigation -->
            <?php include 'header.php'; ?>
            <!-- navigation end -->

            <div id="page-wrapper">
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">
                            Appointment List
                            </h2>
                        </div>
                    </div>
                    <!-- Page Heading end-->

                    <!-- panel start --><h4>Walk in:</h4>
                    <table class="table table-hover table-bordered">
                      <form method="post" action="doctordashboard.php">

                        <th><input type="number" class="form-control" name="icPatient"placeholder="Patient Ic"></th>
                      <th><input type="text" class="form-control" name="patientFirstName" placeholder="FirstName" required></th>
                        <th><input type="text" class="form-control" name="patientLastName"placeholder="Lastname" required></th>
                        <th><input type="text" class="form-control" name="patientPhone"placeholder="ContactNo" required></th>
                        <th><input type="date" class="form-control" name="date" placeholder="Appoint Date" required></th>
                        <th><input type="text" class="form-control" name="startTime" placeholder="Start Time" required></th>
                        <th><input type="text" class="form-control" name="endTime" placeholder="End Time" required></th>
                          <th><select name="appServices" class = "form-control" style="border-radius: 20px">
                            <option value="">Services</option>
                      <?php
                        $rew = mysqli_query($con, "SELECT * FROM services WHERE servicesId");
                        while ($appoint = mysqli_fetch_array($rew)){

                       ?><br/>
                            <option value="<?php echo $appoint['servicesId']; ?>"><?php echo $appoint['Services']; ?></option>
                                                      <?php } ?>
                        </select>
                      </th>
                      <th><input type="text" class="form-control" name="status" placeholder="status" required></th>
                        <!-- <th><input type="text" class="form-control" placeholder="Email" disabled></th> -->

                        <h5><th><button type="submit" name="update" class="btn btn-success" style="border-radius: 20px">Add</button></th>

                    </form>
                  </table>
                    <div class="panel panel-primary filterable">
                        <!-- Default panel contents -->
                       <div class="panel-heading">
                        <h3 class="panel-title">Appointment List</h3>
                        <div class="pull-right">
                            <button class="btn btn-default btn-xs btn-filter"><span class="fa fa-filter"></span> Filter</button>
                        </div>
                        </div>
                        <div class="panel-body">
                        <!-- Table -->
                        <div class="table-responsive">


                        <table id = "example" class="table table-bordered table-striped">
                            <thead>
                                <tr class="filters">

                                    <th><input type="text" class="form-control" placeholder="patient Ic" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="First name" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Last name" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Contact No." disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Day" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Date" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Start" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="End" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Service" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Status" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Complete" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Delete" disabled></th>
                                </tr>
                            </thead>
                            <tbody>


                            <?php
                            $res=mysqli_query($con,"SELECT a.*, b.*
                                                    FROM patient a
                                                    JOIN appointment b
                                                    On a.icPatient = b.patientIc
                                                    WHERE appId
                                                    Order By b.status desc");
                                  if (!$res) {
                                    printf("Error: %s\n", mysqli_error($con));
                                    exit();
                                }
                            while ($appointment=mysqli_fetch_array($res)) {

                                if ($appointment['status']=='process') {
                                    $status="danger";
                                    $icon='remove';
                                    $checked='';

                                } else {
                                    $status="success";
                                    $icon='ok';
                                    $checked = 'disabled';
                                }

                                    echo "<tr class='".$status."'>";
                                    echo "<td>" . $appointment['patientIc'] . "</td>";
                                    echo "<td>" . $appointment['patientFirstName'] . "</td>";
                                    echo "<td>" . $appointment['patientLastName'] . "</td>";
                                    echo "<td>" . $appointment['patientPhone'] . "</td>";
                                    echo "<td>" . $appointment['appToday'] . "</td>";
                                    echo "<td>" . $appointment['appDate'] . "</td>";
                                    echo "<td>" . $appointment['startTime'] . "</td>";
                                    echo "<td>" . $appointment['endTime'] . "</td>";
                                    echo "<td>" . $appointment['appService'] . "</td>";
                                    echo "<td><span class='glyphicon glyphicon-".$icon."' aria-hidden='true'></span>".' '."". $appointment['status'] . "</td>";
                                    echo "<form method='POST'>";
                                    echo "<td class='text-center'><input type='checkbox' name='enable' id='enable' value='".$appointment['appId']."' onclick='chkit(".$appointment['appId'].",this.checked);' ".$checked."></td>";
                                    echo "<td class='text-center'><a href='#' id='".$appointment['appId']."' class='delete'><span class='glyphicon glyphicon-trash' aria-hidden='true'></span></a>
                            </td>";
                              echo "</tr>";
                            }

                           echo "</tbody>";
                       echo "</table>";

                        ?>
                        <div class='panel panel-default'>
                      <div class='col-md-offset-3 pull-right'>
                      <button class='btn btn-primary' type='submit' value='Submit' name='submit'>Update</button>
                       </div>";
                       </div>";
                    </div>
                </div>
              </div>

                    <!-- panel end -->
                    <script type="text/javascript">
    function chkit(uid, chk) {
    chk = (chk==true ? "1" : "0");
    var url = "checkdb.php?userid="+uid+"&chkYesNo="+chk;
    if(window.XMLHttpRequest) {
      req = new XMLHttpRequest();
    } else if(window.ActiveXObject) {
      req = new ActiveXObject("Microsoft.XMLHTTP");
    }
    // Use get instead of post.
    req.open("GET", url, true);
    req.send(null);
    }
    </script>



                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
        </div>
        <!-- /#wrapper -->



        <!-- jQuery -->
        <script src="../patient/assets/js/jquery.js"></script>
            <script src="../patient/assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="assets/js/datatables.min.js"></script>
    <script type="text/javascript" src= "assets/js/datatable.js"></script>
    <script type="text/javascript" src= "assets/js/buttons.print.min.js"></script>
    <script type="text/javascript" src= "assets/js/jszip.min.js"></script>
    <script type="text/javascript" src= "assets/js/pdfmake.min.js"></script>
    <script type="text/javascript" src = "assets/js/buttons.html5.min.js"></script>

        <script type="text/javascript">
    $(function() {
    $(".delete").click(function(){
    var element = $(this);
    var appid = element.attr("id");
    var info = 'id=' + appid;
    if(confirm("Are you sure you want to delete this?"))
    {
    $.ajax({
    type: "POST",
    url: "deleteappointment.php",
    data: info,
    success: function(){
    }
    });
    $(this).parent().parent().fadeOut(300, function(){ $(this).remove();});
    }
    return false;
    });
    });
    </script>
        <!-- Bootstrap Core JavaScript -->
        <!-- Latest compiled and minified JavaScript -->
         <!-- script for jquery datatable start-->
        <script type="text/javascript">
            /*
            Please consider that the JS part isn't production ready at all, I just code it to show the concept of merging filters and titles together !
            */
            $(document).ready(function(){
                $('.filterable .btn-filter').click(function(){
                    var $panel = $(this).parents('.filterable'),
                    $filters = $panel.find('.filters input'),
                    $tbody = $panel.find('.table tbody');
                    if ($filters.prop('disabled') == true) {
                        $filters.prop('disabled', false);
                        $filters.first().focus();
                    } else {
                        $filters.val('').prop('disabled', true);
                        $tbody.find('.no-result').remove();
                        $tbody.find('tr').show();
                    }
                });

                $('.filterable .filters input').keyup(function(e){
                    /* Ignore tab key */
                    var code = e.keyCode || e.which;
                    if (code == '9') return;
                    /* Useful DOM data and selectors */
                    var $input = $(this),
                    inputContent = $input.val().toLowerCase(),
                    $panel = $input.parents('.filterable'),
                    column = $panel.find('.filters th').index($input.parents('th')),
                    $table = $panel.find('.table'),
                    $rows = $table.find('tbody tr');
                    /* Dirtiest filter function ever ;) */
                    var $filteredRows = $rows.filter(function(){
                        var value = $(this).find('td').eq(column).text().toLowerCase();
                        return value.indexOf(inputContent) === -1;
                    });
                    /* Clean previous no-result if exist */
                    $table.find('tbody .no-result').remove();
                    /* Show all rows, hide filtered ones (never do that outside of a demo ! xD) */
                    $rows.show();
                    $filteredRows.hide();
                    /* Prepend no-result row if all rows are filtered */
                    if ($filteredRows.length === $rows.length) {
                        $table.find('tbody').prepend($('<tr class="no-result text-center"><td colspan="'+ $table.find('.filters th').length +'">No result found</td></tr>'));
                    }
                });
            });
        </script>
        <script>
        $(document).ready(function() {
    $('#example').DataTable( {

    } );
    } );
        </script>
        <!-- script for jquery datatable end-->

    </body>
    </html>
