<?php
include_once '../assets/conn/dbconnect.php';
$doctorIc = "";
$doctorFirstName = "";
 $doctorLastName = "";
$doctorEmail = "";
$doctorPhone = "";
$doctorDOB = "";
$doctorGender = "";
$doctorAddress = "";

$doctorId = 0;
if (isset($_POST['update'])) {

  $doctorIc = mysqli_real_escape_string($con, $_POST['doctorIc']);
      $doctorFirstName = mysqli_real_escape_string($con, $_POST['doctorFirstName']);
          $doctorLastName = mysqli_real_escape_string($con, $_POST['doctorLastName']);
              $doctorPhone = mysqli_real_escape_string($con, $_POST['doctorPhone']);
                  $doctorDOB = mysqli_real_escape_string($con, $_POST['doctorDOB']);
                      $doctorGender = mysqli_real_escape_string($con, $_POST['doctorGender']);
                          $doctorAddress = mysqli_real_escape_string($con, $_POST['doctorAddress']);
                              $doctorEmail = mysqli_real_escape_string($con, $_POST['doctorEmail']);



                              $query =  "INSERT INTO doctor ( doctorIc, doctorFirstName, doctorLastName, doctorPhone,  doctorDOB, doctorGender, doctorAddress, doctorEmail)
                               VALUES ( '$doctorIc', '$doctorFirstName', '$doctorLastName', '$doctorPhone', '$doctorDOB', '$doctorGender', '$doctorAddress', '$doctorEmail') ";
                              $result = mysqli_query($con, $query);
                               if( $result ){
                          ?>
                      <script type="text/javascript">
                          alert('New doctor Added.');
                      </script>
                      <?php
                      }

}


include_once '../assets/conn/dbconnect.php';

        if (isset($_POST['update1'])) {
                $doctorIc = mysqli_real_escape_string($con, $_POST['doctorIc']);
                $doctorFirstName = mysqli_real_escape_string($con, $_POST['doctorFirstName']);
                    $doctorLastName = mysqli_real_escape_string($con, $_POST['doctorLastName']);
                        $doctorPhone = mysqli_real_escape_string($con, $_POST['doctorPhone']);
                            $doctorDOB = mysqli_real_escape_string($con, $_POST['doctorDOB']);
                                $doctorGender = mysqli_real_escape_string($con, $_POST['doctorGender']);
                                    $doctorAddress = mysqli_real_escape_string($con, $_POST['doctorAddress']);
                                        $doctorEmail = mysqli_real_escape_string($con, $_POST['doctorEmail']);
                                  $doctorId = mysqli_real_escape_string($con, $_POST['doctorId']);


          mysqli_query($con, "UPDATE doctor SET doctorIc ='$doctorIc', doctorFirstName='$doctorFirstName', doctorLastName='$doctorLastName', doctorAddress='$doctorAddress', doctorGender = '$doctorGender', doctorDOB = '$doctorDOB', doctorPhone = '$doctorPhone', doctorEmail='$doctorEmail' WHERE id = $doctorId");
          $_SESSION['message'] = 'Updated profile';
          $_SESSION['msg_type'] = 'success';
          header("Location: addschedule.php");
        }

 ?>
