<?php
session_start();
include_once 'updateservices.php';

$update = false;
$updated = false;
if (isset($_GET['edit'])) {
  $update = true;
    $timeId = $_GET['edit'];
  $rec = mysqli_query($con, "SELECT * FROM timeschedule WHERE timeId = $timeId");
  $record = mysqli_fetch_array($rec);
  $timeschedule = $record['TimeSchedule'];
  $editstate = true;
}
else if (isset($_GET['edita'])) {
  $updated = true;
    $servicesId = $_GET['edita'];
  $rec = mysqli_query($con, "SELECT * FROM services WHERE servicesId = $servicesId");
  $recorded = mysqli_fetch_array($rec);
  $services = $recorded['Services'];
  $price = $recorded['Price'];
  $editstates = true;
}
// include_once 'connection/server.php';

if(!isset($_SESSION['employeeSession']))
{
header("Location: ../index.php");
}
$usersession = $_SESSION['employeeSession'];
$res=mysqli_query($con,"SELECT * FROM staff WHERE staff='$usersession'");
$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);



?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <?php if ($userRow['Position'] == 'doctor') {
          $admin = "Doctor";
        }else {
          $admin ="Staff";
        }

        echo "<title>Welcome ".$admin." ".$userRow['staffFirstName']."</title>"
        ?><!-- Bootstrap Core CSS -->
        <!-- <link href="assets/css/bootstrap.css" rel="stylesheet"> -->
        <link href="assets/css/material.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="assets/css/sb-admin.css" rel="stylesheet">
        <link href="assets/css/time/bootstrap-clockpicker.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
        <!-- Custom Fonts -->
    </head>
    <body>
        <div id="wrapper">

            <!-- Navigation -->
          <?php include 'header.php'; ?>     <!-- navigation end -->


                <div class="container-fluid">
                    <!-- Page Heading -->

                            <h2 class="page-header">
                            Services
                            </h2>

                    <!-- Page Heading end-->

                    <!-- panel start -->
                    <div class="panel panel-primary filterable">
                      <div class="panel-heading"style="width: auto">
                          <h3 class="panel-title">Service</h3>
                          <div class="pull-right">
                          <button class="btn btn-default btn-xs btn-filter"><span class="fa fa-filter"></span> Filter</button>
                      </div>
                      </div>
                      <div class="row">
                        <!-- panel heading starat -->

                        <!-- panel heading end -->

<div class="col-xs-8 mx-auto">
  <table class="table table-hover table-bordered"style="width: auto">
    <form method="post" action="updateservices.php">

      <?php if($updated == true): ?>
        <input type="hidden" name="servicesId" value="<?php echo $servicesId; ?>">
        <th><input type="text" class="form-control" name="Services" placeholder="patient Ic" value="<?php echo $services; ?>"></th>
          <th><input type="text" class="form-control" name="price" placeholder="patient Ic" value="<?php echo $price; ?>"></th>
      <h5><th><button type="submit" name="updated" class="btn btn-success" style="border-radius: 20px">Update</button></th>
    <?php else: ?>

    <?php endif;  ?>
  </form>
</table>


    <!-- panel heading starat -->


    <!-- panel heading end -->

    <table class="table table-hover table-bordered" style="width: auto">
        <thead>
            <tr class="filters">
                <th><input type="text" class="form-control" placeholder="Service" disabled></th>
                <th><input type="text" class="form-control" placeholder="Price" disabled></th>
                <th colspan="2">Edit<span style="margin-left: 4em"></th>
            </tr>
        </thead>

        <?php
        $result=mysqli_query($con,"SELECT * FROM services");
        while ($serviceRow=mysqli_fetch_array($result)){
          echo "<tbody>";
          echo "<tr>";

?>

          <td> <?php echo $serviceRow['Services'];  ?></td>
          <td> <?php echo $serviceRow['Price'];  ?></td>
          <form method='POST'>
            <td>
              <a href="services.php?edita=<?php echo $serviceRow['servicesId']; ?>" class="btn btn-info" style="border-radius: 50%!important">*</a>
          </td>

<?php
}
echo "</div>";
?>
</div>
</div>
</div>
</div>
    <!-- jQuery -->
        <script src="../patient/assets/js/jquery.js"></script>
        <script type="text/javascript">
$(function() {
$(".delete").click(function(){
var element = $(this);
var ic = element.attr("id");
var info = 'ic=' + ic;
if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: "deletepatient.php",
   data: info,
   success: function(){
 }
});
  $(this).parent().parent().fadeOut(300, function(){ $(this).remove();});
 }
return false;
});
});
</script>
 <script type="text/javascript">
            /*
            Please consider that the JS part isn't production ready at all, I just code it to show the concept of merging filters and titles together !
            */
            $(document).ready(function(){
                $('.filterable .btn-filter').click(function(){
                    var $panel = $(this).parents('.filterable'),
                    $filters = $panel.find('.filters input'),
                    $tbody = $panel.find('.table tbody');
                    if ($filters.prop('disabled') == true) {
                        $filters.prop('disabled', false);
                        $filters.first().focus();
                    } else {
                        $filters.val('').prop('disabled', true);
                        $tbody.find('.no-result').remove();
                        $tbody.find('tr').show();
                    }
                });

                $('.filterable .filters input').keyup(function(e){
                    /* Ignore tab key */
                    var code = e.keyCode || e.which;
                    if (code == '9') return;
                    /* Useful DOM data and selectors */
                    var $input = $(this),
                    inputContent = $input.val().toLowerCase(),
                    $panel = $input.parents('.filterable'),
                    column = $panel.find('.filters th').index($input.parents('th')),
                    $table = $panel.find('.table'),
                    $rows = $table.find('tbody tr');
                    /* Dirtiest filter function ever ;) */
                    var $filteredRows = $rows.filter(function(){
                        var value = $(this).find('td').eq(column).text().toLowerCase();
                        return value.indexOf(inputContent) === -1;
                    });
                    /* Clean previous no-result if exist */
                    $table.find('tbody .no-result').remove();
                    /* Show all rows, hide filtered ones (never do that outside of a demo ! xD) */
                    $rows.show();
                    $filteredRows.hide();
                    /* Prepend no-result row if all rows are filtered */
                    if ($filteredRows.length === $rows.length) {
                        $table.find('tbody').prepend($('<tr class="no-result text-center"><td colspan="'+ $table.find('.filters th').length +'">No result found</td></tr>'));
                    }
                });
            });
        </script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../patient/assets/js/bootstrap.min.js"></script>
        <script src="assets/js/bootstrap-clockpicker.js"></script>

        <!-- Latest compiled and minified JavaScript -->
         <!-- script for jquery datatable start-->
        <!-- Include Date Range Picker -->
    </body>
</html>
