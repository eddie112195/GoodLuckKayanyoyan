<?php
session_start();

include_once 'server.php';
$update = false;
$male="";
$female="";
$single="";
$married="";
$separated="";
$divorced="";
$widowed="";
if (isset($_GET['edit'])) {
  $update = true;
    $patientId = $_GET['edit'];

  $rec = mysqli_query($con, "SELECT * FROM patient WHERE patientId = $patientId");
  $record = mysqli_fetch_array($rec);
  $icPatient = $record['icPatient'];
  $Username = $record['Username'];
  $patientFirstName = $record['patientFirstName'];
  $patientLastName = $record['patientLastName'];
  $password = $record['password'];
  $patientPhone = $record['patientPhone'];
  $patientMaritialStatus = $record['patientMaritialStatus'];
  $patientDOB = $record['patientDOB'];
  $patientGender = $record['patientGender'];
  $patientAddress = $record['patientAddress'];
  $patientPhone = $record['patientPhone'];
  $patientEmail = $record['patientEmail'];
  $editstate = true;

  if ($record['patientGender']=='male') {
  $male = 'male';
}elseif ($record['patientGender']=='female') {
  $female = "female";
  }
  if ($record['patientMaritialStatus']=='single') {
  $single = "single";
}elseif ($record['patientMaritialStatus']=='married') {
  $married = "married";
}elseif ($record['patientMaritialStatus']=='separated') {
  $separated = "separated";
}elseif ($record['patientMaritialStatus']=='divorced') {
  $divorced = "divorced";
}elseif ($record['patientMaritialStatus']=='widowed') {
  $widowed = "widowed";
  }

}
// include_once 'connection/server.php';
if(!isset($_SESSION['employeeSession']))
{
header("Location: ../index.php");
}

$usersession = $_SESSION['employeeSession'];
$res=mysqli_query($con,"SELECT * FROM staff WHERE staff='$usersession'");
$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <?php if ($userRow['Position'] == 'doctor') {
          $admin = "Doctor";
        }else {
          $admin ="Staff";
        }

        echo "<title>Welcome ".$admin." ".$userRow['staffFirstName']."</title>"
        ?>
        <!-- Bootstrap Core CSS -->
        <!-- <link href="assets/css/bootstrap.css" rel="stylesheet"> -->
        <link href="assets/css/material.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="assets/css/sb-admin.css" rel="stylesheet">
        <link href="assets/css/time/bootstrap-clockpicker.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <script src="assets/js/jquery-3.3.1.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="assets/css/jquery.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="assets/css/buttons.dataTables.min.css"/>
        <script type="text/javascript" src="assets/js/dataTables.buttons.min.js"></script>
        <script src="assets/js/dataTables.buttons.min.js" type="text/javascript"></script>
        <script src="assets/js/buttons.flash.min.js" type="text/javascript"></script>
        <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
        <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

        <!--Font Awesome (added because you use icons in your prepend/append)-->
        <link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

        <!-- Inline CSS based on choices in "Settings" tab -->
        <style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>

        <!-- Custom Fonts -->
    </head>
    <body>
        <div id="wrapper">

            <!-- Navigation -->
            <?php include 'header.php'; ?>
            <!-- navigation end -->

            <div id="page-wrapper">
                <div class="container-fluid">

                    <!-- Page Heading -->
                        <div class="col-lg-12">
                            <h2 class="page-header">
                            Patient List
                            </h2>
                        </div>
                    <!-- Page Heading end-->

                    <!-- panel start -->
                    <?php if (isset($_SESSION ['message'])):

                     ?>
                     <div class="alert alert-<?=$_SESSION['msg_type']?>">
                       <?php
                            echo $_SESSION['message'];
                            unset($_SESSION['message']);
                          ?>
                        </div>
                      <?php endif ?>
                    <div class="panel panel-primary filterable">
                      <table class="table table-hover table-bordered">
                        <form method="post" action="updatepatient.php">

                          <?php if($update == true): ?>
                            <input type="hidden" name="patientId" value="<?php echo $patientId; ?>">
                            <th><input type="number" class="form-control" name="icPatient" placeholder="patient Ic" value="<?php echo $icPatient; ?>"></th>
                            <th><input type="text" class="form-control" name="Username" placeholder="Username" value="<?php echo $Username; ?>"></th>
                            <th><input type="text" class="form-control" name="patientFirstName"placeholder="First name" value="<?php echo $patientFirstName; ?>"></th>
                            <th><input type="text" class="form-control" name="patientLastName" placeholder=" Last name" value="<?php echo $patientLastName; ?>"></th>
                            <th><input type="text" class="form-control" name="patientPhone" placeholder="ContactNo." value="<?php echo $patientPhone; ?>"></th>
                            <!-- <th><input type="text" class="form-control" placeholder="Email" disabled></th> -->
                            <th><input type="text" class="form-control" name="patientGender" placeholder="Gender" value="<?php echo $patientGender; ?>"> </th>
                            <th><input type="email" class="form-control" name="patientEmail" placeholder="Email" value="<?php echo $patientEmail; ?>"></th>
                            <th> <input type="text" class="form-control" name="patientMaritialStatus" placeholder="Status" value="<?php echo $patientMaritialStatus; ?>">
                                </th>
                            <th><input type="date" class="date_input" name="patientDOB" placeholder="Birthdate" value="<?php echo $patientDOB; ?>"></th>
                            <th><input type="text" class="form-control" name="patientAddress" placeholder="Address" value="<?php echo $patientAddress; ?>"></th>
                          <h5><th><button type="submit" name="update" class="btn btn-success" style="border-radius: 20px">Update</button></th>
                        <?php else: ?>
                          <input type="hidden" name="patientId" value="<?php echo $patientId; ?>">
                          <th><input type="hidden" class="form-control" name="icPatient" placeholder="patient Ic" value="<?php echo $icPatient; ?>" disabled></th>
                          <th><input type="hidden" class="form-control" name="Username" placeholder="Username" value="<?php echo $Username; ?>" disabled></th>
                          <th><input type="hidden" class="form-control" name="patientFirstName"placeholder="First name" value="<?php echo $patientFirstName; ?>" disabled></th>
                          <th><input type="hidden" class="form-control" name="patientLastName" placeholder=" Last name" value="<?php echo $patientLastName; ?>"disabled></th>
                          <th><input type="hidden" class="form-control" name="patientPhone" placeholder="ContactNo." value="<?php echo $patientPhone; ?>"disabled></th>
                          <!-- <th><input type="text" class="form-control" placeholder="Email" disabled></th> -->
                          <th><input type="hidden" class="form-control" name="patientGender" placeholder="Gender" value="<?php echo $patientGender; ?>"disabled> </th>
                          <th><input type="hidden" class="form-control" name="patientEmail" placeholder="Email" value="<?php echo $patientEmail; ?>"disabled></th>
                          <th> <input type="hidden" class="form-control" name="patientMaritialStatus" placeholder="Status" value="<?php echo $patientMaritialStatus; ?>"disabled>
                              </th>
                          <th><input type="hidden" class="date_input" name="patientDOB" placeholder="Birthdate" value="<?php echo $patientDOB; ?>"disabled></th>
                          <th><input type="hidden" class="form-control" name="patientAddress" placeholder="Address" value="<?php echo $patientAddress; ?>"disabled></th>

                        <?php endif;  ?>
                      </form>
                    </table>
                        <!-- panel heading starat -->
                        <div class="panel-heading">
                            <h3 class="panel-title">List of Patients</h3>
                            <div class="pull-right">
                            <button class="btn btn-default btn-xs btn-filter"><span class="fa fa-filter"></span> Filter</button>
                        </div>
                        </div>
                        <!-- panel heading end -->

                        <div class="panel-body">
                        <!-- panel content start -->
                           <!-- Table -->
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr class="filters">
                                    <th><input type="text" class="form-control" placeholder="patient Ic" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Username" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="First name" disabled></th>
                                    <th><input type="text" class="form-control" placeholder=" Last name" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="ContactNo." disabled></th>
                                    <!-- <th><input type="text" class="form-control" placeholder="Email" disabled></th> -->
                                    <th><input type="text" class="form-control" placeholder="Gender" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Email" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Status" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Birthdate" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Address" disabled></th>
                                    <th colspan="1">Edit</th>
                                </tr>
                            </thead>

                            <?php
                            $result=mysqli_query($con,"SELECT * FROM patient");
                            while ($patientRow=mysqli_fetch_array($result)){
                              echo "<tbody>";
                              echo "<tr>";

?>

                              <td> <?php echo $patientRow['icPatient'];  ?></td>
                              <td> <?php echo $patientRow['Username'];  ?></td>
                              <td> <?php echo $patientRow['patientFirstName'];  ?></td>
                            <td> <?php echo $patientRow['patientLastName'];  ?></td>
                              <td> <?php echo $patientRow['patientPhone'];  ?></td>
                              <td> <?php echo $patientRow['patientGender'];  ?></td>
                              <td> <?php echo $patientRow['patientEmail'];  ?></td>
                              <td> <?php echo $patientRow['patientMaritialStatus'];  ?></td>
                              <td> <?php echo $patientRow['patientDOB'];  ?></td>
                              <td> <?php echo $patientRow['patientAddress'];  ?></td>
                              <form method='POST'>
                                <td>
                                  <a href="updatepatient.php?edit=<?php echo $patientRow['patientId']; ?>" class="btn btn-info" style="border-radius: 50%!important">*</a>
                              </td>
                              
</div>
</div>
<?php
          }

?>

    <!-- jQuery -->
        <script src="../patient/assets/js/jquery.js"></script>
        <script type="text/javascript">
$(function() {
$(".delete").click(function(){
var element = $(this);
var ic = element.attr("id");
var info = 'ic=' + ic;
if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: "deletepatient.php",
   data: info,
   success: function(){
 }
});
  $(this).parent().parent().fadeOut(300, function(){ $(this).remove();});
 }
return false;
});
});
</script>
 <script type="text/javascript">
            /*
            Please consider that the JS part isn't production ready at all, I just code it to show the concept of merging filters and titles together !
            */
            $(document).ready(function(){
                $('.filterable .btn-filter').click(function(){
                    var $panel = $(this).parents('.filterable'),
                    $filters = $panel.find('.filters input'),
                    $tbody = $panel.find('.table tbody');
                    if ($filters.prop('disabled') == true) {
                        $filters.prop('disabled', false);
                        $filters.first().focus();
                    } else {
                        $filters.val('').prop('disabled', true);
                        $tbody.find('.no-result').remove();
                        $tbody.find('tr').show();
                    }
                });

                $('.filterable .filters input').keyup(function(e){
                    /* Ignore tab key */
                    var code = e.keyCode || e.which;
                    if (code == '9') return;
                    /* Useful DOM data and selectors */
                    var $input = $(this),
                    inputContent = $input.val().toLowerCase(),
                    $panel = $input.parents('.filterable'),
                    column = $panel.find('.filters th').index($input.parents('th')),
                    $table = $panel.find('.table'),
                    $rows = $table.find('tbody tr');
                    /* Dirtiest filter function ever ;) */
                    var $filteredRows = $rows.filter(function(){
                        var value = $(this).find('td').eq(column).text().toLowerCase();
                        return value.indexOf(inputContent) === -1;
                    });
                    /* Clean previous no-result if exist */
                    $table.find('tbody .no-result').remove();
                    /* Show all rows, hide filtered ones (never do that outside of a demo ! xD) */
                    $rows.show();
                    $filteredRows.hide();
                    /* Prepend no-result row if all rows are filtered */
                    if ($filteredRows.length === $rows.length) {
                        $table.find('tbody').prepend($('<tr class="no-result text-center"><td colspan="'+ $table.find('.filters th').length +'">No result found</td></tr>'));
                    }
                });
            });
        </script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../patient/assets/js/bootstrap.min.js"></script>
        <script src="assets/js/bootstrap-clockpicker.js"></script>

        <!-- Latest compiled and minified JavaScript -->
         <!-- script for jquery datatable start-->
        <!-- Include Date Range Picker -->
    </body>
</html>
