<?php
session_start();
include_once '../assets/conn/dbconnect.php';
// include_once 'connection/server.php';
if(!isset($_SESSION['employeeSession']))
{
header("Location: ../index.php");
}
$usersession = $_SESSION['employeeSession'];
$res=mysqli_query($con,"SELECT * FROM staff WHERE staff='$usersession'");
$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);



?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Monthly</title>
      <!-- Bootstrap Core CSS -->
        <!-- <link href="assets/css/bootstrap.css" rel="stylesheet"> -->
        <link href="assets/css/material.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="assets/css/sb-admin.css" rel="stylesheet">
        <link href="assets/css/time/bootstrap-clockpicker.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <script src="assets/js/jquery.min.js"></script>
 <link rel="stylesheet" type="text/css" href="assets/css/datatables.min.css"/>
 <link rel="stylesheet" type = "text/css" href="assets/css/buttons.datatables.min.css">


        <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
        <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

        <!--Font Awesome (added because you use icons in your prepend/append)-->
        <link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

        <!-- Inline CSS based on choices in "Settings" tab -->
        <style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>

        <!-- Custom Fonts -->
    </head>
    <body>
        <div id="wrapper">

            <!-- Navigation -->
            <?php include 'header.php'; ?>
             <!-- navigation end -->

            <div id="page-wrapper">
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">
                            Monthly Income
                            </h2>
                            <ol class="breadcrumb">

                                <div class="container box">
                                  <h3 align="center"></h3>
                                  <div class="table-responsive" style="width: 120%; margin-left: -110px">
                                    <table id="data" class="table table-bordered table-striped" >
                                      <thead>
                                        <tr>
                                          <th>Patient IC</th>
                                          <th>First Name</th>
                                          <th>Last Name</th>
                                          <th>ContactNo</th>
                                          <th>Date</th>
                                          <th>Start</th>
                                          <th>End</th>
                                          <th>Service</th>
                                          <th>Price</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                      <?php
                                      $res=mysqli_query($con,"SELECT a.*, b.*
                                                              FROM patient a
                                                              JOIN appointment b
                                                              On a.icPatient = b.patientIc
                                                              Order By appId desc");


                                      while ($appointment = $res->fetch_array()) {

                                              echo "<td>" . $appointment['patientIc'] . "</td>";
                                              echo "<td>" . $appointment['patientFirstName'] . "</td>";
                                              echo "<td>" . $appointment['patientLastName'] . "</td>";
                                              echo "<td>" . $appointment['patientPhone'] . "</td>";
                                              echo "<td>" . $appointment['appDate'] . "</td>";
                                              echo "<td>" . $appointment['startTime'] . "</td>";
                                              echo "<td>" . $appointment['endTime'] . "</td>";
                                              echo "<td>" . $appointment['appService'] . "</td>";
                                              echo "<td>" . $appointment['Price'] . "</td>";
                                              echo "</tr>";

                                      }
                                      echo "</tbody>";
                                        echo "</table>";


                                  ?>


                                  </div>
                                </div>
                                <br />
                                <br />
                            </ol>
                        </div>
                    </div>
                    <!-- Page Heading end-->

                    <!-- panel start -->

        <!-- script for jquery datatable end-->



                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
        </div>
        <!-- /#wrapper -->
            <script src="../patient/assets/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="assets/js/jquery-3.3.1.js"></script>
        <script type="text/javascript" src="assets/js/datatables.min.js"></script>
        <script type="text/javascript" src= "assets/js/datatable.js"></script>
        <script type="text/javascript" src= "assets/js/buttons.print.min.js"></script>
        <script type="text/javascript" src= "assets/js/jszip.min.js"></script>
        <script type="text/javascript" src= "assets/js/pdfmake.min.js"></script>
        <script type="text/javascript" src = "assets/js/buttons.html5.min.js"></script>


        <script>
        $(document).ready(function() {
    $('#data').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            {extend:'copy', className: 'btn btn-primary'},
            {extend:'excel', className: 'btn btn-primary'},
             {extend:'print', className: 'btn btn-primary'}
        ]
    } );
} );
        </script>


        <!-- script for jquery datatable end-->
    </body>
</html>
